https://www.fordham.edu/about/campuses/rose-hill-campus/mcshane-campus-center/explore-naming-opportunities

# Explore Naming Opportunities

Your help is needed in keeping our project on track. Our current phase of construction includes a complete reimagining of dining at Rose Hill, to put us on par with our competitors, and renovation of the old McGinley Center space to support student activities.

A unique way to leave your mark on Fordham while protecting its legacy is to name a space for you, your family, or in honor of a loved one. Several spaces are available in the McShane Center.

To learn more about naming opportunities, contact Michael Boyd, senior associate vice president of development and university relations, at 212-636-6525 or [[email protected]](/cdn-cgi/l/email-protection#bad7d8d5c3de8dfadcd5c8ded2dbd794dfdecf).

## Marquis Spaces

Marketplace Dining | Fitness Center | Great Hall | Large Multi-Purpose Commons | Gallery | Arcade | Exterior Plaza

## Gathering Spaces

Conference Room | Career Center Interview Rooms | Elevator Landings/Lobbies | Private Dining Rooms | Career Center Director’s Office | Career Center Commons Area | Second Floor Offices

## Other Fitness Spaces

Weight Training Area | Yoga and Dance Studio | Aerobic Exercise Room