https://www.fordham.edu/about/leadership-and-administration/administrative-offices/external-affairs/center-for-community-engaged-learning/ccel-conversations/ccel-conversation-archives-/our-lady-of-guadalupe

# Our Lady of Guadalupe

**Our Lady of Guadalupe: Queen of Mexico and Patroness of the Americas**

*December 8. 2021, **Remote*

On December 8, 2021, Fordham University’s Center for Community Engaged Learning hosted a conversation with Juan Aguirre, titled, “Our Lady of Guadalupe”. In this discussion, Juan highlighted her significance, history, and importance to Mexican culture. He utilized artifacts, historical documents, photographs, and artwork to support his presentation.

**Resources**: