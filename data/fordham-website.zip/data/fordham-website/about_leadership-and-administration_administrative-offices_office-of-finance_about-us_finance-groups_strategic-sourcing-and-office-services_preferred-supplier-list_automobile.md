https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-finance/about-us/finance-groups/strategic-sourcing-and-office-services/preferred-supplier-list/automobile

# Automobile

**Products/Service Summary**

Comprehensive Fleet Management Services including:

- Open-end leases

- Maintenance management programs

- License, title, and registration services

- Plus other services

**Purchasing Method**

- Open-end lease

Contact Alessandro Mazzotta at [[email protected]](/cdn-cgi/l/email-protection#abcac6cad1d1c4dfdfca98ebcdc4d9cfc3cac685cecfde) for purchase options.

**Strategic Sourcing Contac**t

- Alessandro Mazzotta, Director of Strategic Sourcing and Office Services