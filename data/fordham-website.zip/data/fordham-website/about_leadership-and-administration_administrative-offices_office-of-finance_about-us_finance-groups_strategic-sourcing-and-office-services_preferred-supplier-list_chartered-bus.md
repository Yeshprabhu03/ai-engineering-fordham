https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-finance/about-us/finance-groups/strategic-sourcing-and-office-services/preferred-supplier-list/chartered-bus

# Chartered Bus

**Products/Service Summary **Bus charter services offers a diverse fleet to accommodate various group sizes and travel needs, from athletic teams to University Sponsored Events.

**Purchasing Method **

Contact Vendor

**Supplier Contacts**

Academy Express Antonio Ramos [[email protected]](/cdn-cgi/l/email-protection#204152414d4f536041434144454d594255530e434f4d)

Silver Star Transporation Mario Da Rocha Jr [[email protected]](/cdn-cgi/l/email-protection#b6dbd7c4dfd9dcc4f6c5dfdac0d3c4c5c2d7c4c2c4d7d8c5c6d9c4c2d7c2dfd9d898d5d9db)


**Fordham Contact**

Strategic Sourcing Contact Gina Raymundo [[email protected]](/cdn-cgi/l/email-protection)