https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-the-president/about/alpha-sigma-nu/alpha-sigma-nu-executive-board

# Alpha Sigma Nu Executive Board

## 2023-2024

President – Cristina Scofield

Vice President for Ignatian Programming – Chaise Jones

Vice President for Community Engagement – Gesilda Noka

Secretary – Jaya Joyce

Chapter Coordinator – Gil Severiano, Office of Campus Ministry

Advisor – Vanessa Rotondo, Office of the President

Contact the Executive Board: [[email protected]](/cdn-cgi/l/email-protection#c0a1acb0a8a1b3a9a7ada1aeb580a6afb2a4a8a1adeea5a4b5)