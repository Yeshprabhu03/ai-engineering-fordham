https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-the-provost/about-us/gainful-employment-disclosure/bilingual-school-psychology

# Graduate certificate in Bilingual School Psychology

**This program is designed to be completed in 90 weeks.**

**This program will cost $99,864 if completed within normal time. There may be additional costs for living expenses. These costs were accurate at the time of posting, but may have changed.**

**Of the students who completed this program within normal time, the typical graduate leaves with N/A* of debt.**

*Fewer than 10 students completed this program within normal time. This number has been withheld to preserve the confidentiality of the students.

**Program meets licensure requirements in the following States: **New York

For more information about graduation rates, loan repayment rates, and post-enrollment earnings about this institution and other postsecondary institutions please click here: **https://collegescorecard.ed.gov/**