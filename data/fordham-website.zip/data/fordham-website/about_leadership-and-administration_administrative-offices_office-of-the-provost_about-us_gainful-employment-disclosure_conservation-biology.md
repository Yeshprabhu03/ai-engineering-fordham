https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-the-provost/about-us/gainful-employment-disclosure/conservation-biology

# Graduate certificate in Conservation Biology

**This program is designed to be completed in 30 weeks.**

**This program will cost $24,148 if completed within normal time. There may be additional costs for living expenses. These costs were accurate at the time of posting, but may have changed.**

**Of the students who completed this program within normal time, the typical graduate leaves with N/A* of debt.**

*Fewer than 10 students completed this program within normal time. This number has been withheld to preserve the confidentiality of the students.

**Program does not meet licensure requirements in the following States: **Alabama, Alaska, American Samoa, Arizona, Arkansas, California, Colorado, Connecticut, Delaware, District of Columbia, Federated States of Micronesia, Florida, Georgia, Guam, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky, Louisiana, Maine, Marshall Islands, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina, North Dakota, Northern Marianas, Ohio, Oklahoma, Oregon, Palau, Pennsylvania, Puerto Rico, Rhode Island, South Carolina, South Dakota, Tennessee, Texas, Utah, Vermont, Virgin Islands, Virginia, Washington, West Virginia, Wisconsin, Wyoming

For more information about graduation rates, loan repayment rates, and post-enrollment earnings about this institution and other postsecondary institutions please click here: **https://collegescorecard.ed.gov/**