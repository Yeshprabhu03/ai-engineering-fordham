https://www.fordham.edu/about/leadership-and-administration/administrative-offices/office-of-the-provost/provost-office-units/faculty-affairs/reappointment-tenure--promotion

# Reappointment, Tenure & Promotion

Tenured, tenure-track, and non-tenure-track faculty: find everything you need to know to navigate the RPT process.

[Guide to your Road to Tenure](/about/leadership-and-administration/administrative-offices/office-of-the-provost/provost-office-units/faculty-affairs/reappointment-tenure--promotion/guide-to-your-road-to-tenure/)- Norms for TT Faculty
*(Access required)* [RPT System](/about/leadership-and-administration/administrative-offices/office-of-the-provost/provost-office-units/faculty-affairs/reappointment-tenure--promotion/rpt-system/)[RPT Calendar](/about/leadership-and-administration/administrative-offices/office-of-the-provost/provost-office-units/faculty-affairs/reappointment-tenure--promotion/rpt-calendar/)

Tenured, tenure-track, and non-tenure-track faculty: find everything you need to know to navigate the RPT process.