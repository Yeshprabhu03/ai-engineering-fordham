https://www.fordham.edu/about/living-the-mission/campus-ministry/retreat-ministry/retreat-ministry-calendar

# Campus Ministry Retreats Calendar

|
FreshVision Retreat *First Year and Transfer Students Only* |
September 26 - 28, 2025 |
|
Jewish Shabbaton Retreat |
October 3 - 5, 2026 |
|
Romero Retreat (NEW! Retreat with a focus on Contemplative Leaders in Action) |
October 10 - 12, 2025 |
|
Cor Retreat |
November 7 - 9, 2025 |
|
Emmaus Retreat |
November 21 - 23, 2025 |

|
Contemplatio Retreat |
January 16 - 19, 2026 |
|
Art & Yoga Retreat |
February 6 - 8, 2026 |
|
FreshVision Retreat *First Year and Transfer Students Only* |
February 20 - 22, 2026 |
|
Cor Retreat |
February 27 - March 1, 2026 |
|
Ramadan Retreat |
March 6 - 8, 2026 |
|
Prism LGBTQ+ Retreat |
March 20 - 22, 2026 |
|
Emmaus Retreat |
March 27 - 29, 2026 |
|
Charis Senior Retreat |
April 10 - 12, 2026 |


![Picture Frame that says](/media/home/departments-centers-and-offices/campus-ministry/pdfs/unnamed.jpg)