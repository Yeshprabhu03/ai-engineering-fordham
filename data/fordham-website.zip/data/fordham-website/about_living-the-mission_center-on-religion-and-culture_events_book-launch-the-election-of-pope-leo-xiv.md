https://www.fordham.edu/about/living-the-mission/center-on-religion-and-culture/events/book-launch-the-election-of-pope-leo-xiv

# Book Launch: 'The Election of Pope Leo XIV'

**Authors Gerard O’Connell and Elisabetta Piqué on ***The Election of Pope Leo XIV*

*The Election of Pope Leo XIV*

*
*


![](/media/home/departments-centers-and-offices/center-on-religion-and-culture/O-Connell_Election-Pope-Leo-FinalCvr-1.jpg)

**March 25, 2026 | 6:00 – 7:30 p.m. Fordham University at Lincoln Center | 12th Floor Lounge113 W 60th Street | New York, NY 10023**

Please join the [Center on Religion and Culture](https://www.fordham.edu/about/living-the-mission/center-on-religion-and-culture/) and [America Media](https://www.americamagazine.org/) to celebrate [Orbis Books](https://orbisbooks.com/products/the-election-of-pope-leo-xiv-the-last-suprise-of-pope-francis?srsltid=AfmBOoosH7bPmKgC-e63B7_WjsEwnkriKEHI_pYdOLCPhfskFgCidyhJ)' publication of *The Election of Pope Leo XIV: The Last Surprise of Pope Francis** *on Wednesday, March 25th, from 6:00-7:30pm.

Authors **Gerard O’Connell**,** **senior Vatican correspondent at America Media,** **and **Elisabetta Piqué**, correspondent for *La Nacion*, the Argentine daily published in Buenos Aires, and author of three books including *Francis, Life and Revolution*, will talk about the conclave and their book, and take questions from the audience.

Light bites and drinks will be served. Signed copies of the book will be available for purchase.