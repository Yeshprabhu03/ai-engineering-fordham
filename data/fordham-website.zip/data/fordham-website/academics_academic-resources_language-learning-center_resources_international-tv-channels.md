https://www.fordham.edu/academics/academic-resources/language-learning-center/resources/international-tv-channels

# International TV Channels for Language Students

Both facilities offer the opportunity for language students to stream International TV programming at our work stations. Here are some of the channels we offer:

- RAI (Italian)
- TV 5 (French)
- NTV America (Russian)
- Dubai (Arabic)
- Deutsche Welle (German)
- CCTV 4 (Mandarin)
- Telemundo (Spanish)