https://www.fordham.edu/academics/centers-and-institutes/center-for-ethics-education/ethics-grants-awards-and-prizes/chynn-ethics-paper-prize/2018-prize-winners

# Chynn Ethics Paper 2018 Prize Winners

## First Prize Winner

Sarah Reis

[The Homeless as Human Subjects](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Reis_The_Homeless_as_Human_Subjects__.pdf)

Fordham College Rose Hill, '18

## Second Prize Winner

Carli Grace

[A Doctor's Beauty](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Grace_A_Dotor_s_Beauty.pdf)

Fordham College Rose Hill, '18

## Third Prize Winner

Brett Taylor

[The Clinical Dialectic: What Makes Life Worth Living?](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Taylor_The_Clinical_Dialectic_What_Makes_Life_Worth_Living.pdf)

Fordham College Rose Hill, '18

## Honorable Mentions

Dena Bussa

[The Argument for Selfishness in the Long-Term](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Bussa_The_Argument_for_Selfishness_in_the_Long_Term.pdf)

Gabelli School of Business, '18

Jeremy Cruz

[Thank You?](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Cruz_Thank_You.pdf)

Gabelli School of Business, '18

Elizabeth Doty

[On Protecting the Agency of Undocumented Immigrants from Patterns of Our Past](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Doty_On_Protecting_the_Agency_of_Undocumented_Immigrants_from_Patterns_of_Our_Past.pdf)

Fordham College Rose Hill, '18

Gianna Insogna

[A Matter of Life and Death](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Insogna_A_Matter_of_Life_and_Death.pdf)

Fordham College Rose Hill, '19

Bradley Sylvester

[Naloxone: Another Shot at Life](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Sylvester_Naloxone_Another_Shot_at_Life.pdf)

Fordham College Rose Hill, '18

Maria Trivelpiece

[Boys will be Boys: The Promise of the Good Life and the Inequalities it Forgot ](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Trivelpiece_Boys_will_Boys_The_Promise_of_the_Good_Life_and_the_Inequalities_it_Forgot_to_Disclose.pdf)

Fordham College Rose Hill, '19

Christopher Tucci

[That Is All](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Tucci_Paper_2.pdf)

Fordham College Rose Hill, '18

Pearse Walsh

[How Pondering About Good Boys Leads to the Acceptance of Virtue Theory and Consequent Rejection of Individualism](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Walsh_How_Pondering_About_Good_Boys_Leads_to_the_Acceptance_of_Virtue_Theory_and_Consequent_Rejection_of_Individualism.pdf)

Fordham College Rose Hill, '19

Edie Weinhardt

[Before You Stir: How Kant and Stanton Prove the Tech Industry is Failing Women](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Weinhardt_Before_You_Stir_How_Kant_and_Stanton_Prove_the_Tech_Industry_is_Failing_Women.pdf)

Fordham College Rose Hill, '20

Kathryn Wolper

[A Reflection on Looking, Seeing, and Being Seen](/media/review/content-assets/migrated/pdfs/jadu-single-folder-pdfs/Wolper_A_Reflection_on_Looking__Seeing__and_Being_Seen.pdf)

Fordham College Rose Hill, '18