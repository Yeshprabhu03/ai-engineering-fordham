https://www.fordham.edu/academics/centers-and-institutes/center-for-ethics-education/hiv-and-drug-abuse-prevention-research-ethics-training-institute/resources/hiv-and-drug-abuse-research-ethics-publications-and-presentations

# HIV and Drug Abuse Research Ethics Publications and Presentations

Fordham University HIV and Drug Abuse Prevention Research Ethics Training Institute (RETI) Fellows are encouraged to disseminate the findings of their Mentored Research Project through publications and presentations. Listed below are a selection of publications and presentations funded by the RETI, as well as fellows' related research ethics publications and presentations.