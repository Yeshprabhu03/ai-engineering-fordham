https://www.fordham.edu/academics/departments/african--african-american-studies/faculty

# African and African American Studies Faculty

[Jane Kani Edward](/academics/departments/african--african-american-studies/faculty/jane-kani-edward/)

Associate Professor and Chair

Office: Dealy Hall 636 (RH)

Email: [[email protected]](/cdn-cgi/l/email-protection#3c59584b5d4e587c5a534e58545d5112595849)

Phone: 718-817-3746

[Mark L. Chapman](/academics/departments/african--african-american-studies/faculty/mark-l-chapman/)

Associate Professor and Associate Chair

Office: Dealy Hall 635 (RH)

Email: [[email protected]](/cdn-cgi/l/email-protection#05666d647568646b45636a77616d64682b606170)

Phone: 718-817-3747

[Mark D. Naison](/academics/departments/african--african-american-studies/faculty/mark-d-naison/)

Professor

Office: Dealy Hall 640 (RH)

Email: [[email protected]](/cdn-cgi/l/email-protection#6608070f15090826000914020e070b48030213)

Phone: 718-817-3748

[Laurie Lambert](/academics/departments/african--african-american-studies/faculty/laurie-lambert/)

Associate Professor

Office: Lowenstein 414F (LC)

Email: [[email protected]](/cdn-cgi/l/email-protection#224e4e434f404750561162444d50464a434f0c474657)

Phone: 212-636-7655

[Tyesha Maddox](/academics/departments/african--african-american-studies/faculty/tyesha-maddox/)

Assistant Professor

Office: Dealy Hall 638

Email: [[email protected]](/cdn-cgi/l/email-protection#e3978e8287878c9bd2a3858c91878b828ecd868796)

Phone: 718-817-0594

[Claude Mangum](/academics/departments/african--african-american-studies/faculty/claude-j-mangum/)

Emeritus Associate Professor

Email: [[email protected]](/cdn-cgi/l/email-protection#107d717e77657d50767f627478717d3e757465)

[Irma Watkins Owens](/academics/departments/african--african-american-studies/faculty/irma-watkins-owens/)

Emerita Associate Professor

Email: [[email protected]](/cdn-cgi/l/email-protection#6f180e1b0406011c00180a011c2f09001d0b070e02410a0b1a)