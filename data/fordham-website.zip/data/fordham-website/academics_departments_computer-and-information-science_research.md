https://www.fordham.edu/academics/departments/computer-and-information-science/research

# CIS Research

![Three Students with Robots](/media/review/content-assets/migrated/images/RobotPhoto1800.jpg)


#### Highlights of Latest Activities in CIS Department

## CIS Research Making Major Impact

### Highlights of the academic year 2020

### Highlights of the academic year 2020

- 2020 Faculty Publications:
-
Publications in respected journals, conferences and books: 85


-
- 2020 Grants:
-
Grants submitted: 21 for $12.7M

-
Ongoing grants: 5 for $1.3M


-
- 2020 Professional Services:
-
Editor/editorial board: 21

-
Guest editor: 15

-
Conf/Prog chair: 11

-
Conf committee: 46


-

### Highlights of the academic year 2019

### Highlights of the academic year 2019

- 2019 Faculty Publications:
-
Publications in respected journals, conferences and books: 96


-
- 2019 Grants:
-
Grants submitted: 15 for $8.3M

-
Ongoing grants: 5 for $1.3M


-
- 2019 Professional Services:
-
Editor/editorial board: 19

-
Guest editor: 13

-
Conf/Prog chair: 9

-
Conf committee: 43


-