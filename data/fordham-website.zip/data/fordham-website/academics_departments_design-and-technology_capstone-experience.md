https://www.fordham.edu/academics/departments/design-and-technology/capstone-experience

# Design and Technology Capstone Experience

The NMDD major culminates in a Capstone Experience in the senior year. Graduating seniors create Capstone Projects within a collective studio workshop setting. Once completed, all Capstone Projects are exhibited and archived in our [NMDD Capstone Exhibition website](https://nmddcapstone.ace.fordham.edu/).