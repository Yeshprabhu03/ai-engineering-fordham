https://www.fordham.edu/academics/departments/english/faculty/stacey-derasmo

# Stacey D'Erasmo

![Stacey D'Erasmo, Stacey, English Faculty](/media/review/content-assets/migrated/images/Stacey_D_Erasmo.jpg)


## Professor

B.A. Barnard College; M.A. New York University

Research and Teaching Interests: Creative Writing


-
[Stacey D'Erasmo](/cdn-cgi/l/email-protection#9deef9f8effceef0f2ddfbf2eff9f5fcf0b3f8f9e8)is the author of three novels. Her first novel,*Tea*(Algonquin, 2000), was selected as a*New York Times*Notable Book. Her second novel,*A Seahorse Year*(Houghton Mifflin, 2004), was named a Best Book of the Year by the*San Francisco Chronicle*and*Newsday*and won both a Lambda Literary Award and a Ferro-Grumley Award. Her third novel,*The Sky Below*, was published by*Houghton Mifflin Harcourt*in January, 2009. D'Erasmo's articles and podcasts have been published in*The New York Times Book Review*,*New York Times**Magazine*,*Ploughshares*, and the*Los Angeles Times*. She has been a faculty member at the Breadloaf Writers Conference in 2007 and 2008.