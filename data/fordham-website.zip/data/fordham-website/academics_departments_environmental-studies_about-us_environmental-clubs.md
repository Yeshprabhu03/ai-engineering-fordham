https://www.fordham.edu/academics/departments/environmental-studies/about-us/environmental-clubs

# Environmental Clubs

Clubs at Rose Hill and Lincoln Center sponsored by Environmental Studies provide you with the opportunity to participate in a close-knit community of learners beyond the classroom and pursue activities such as campus ecology projects, invited speakers, career fairs, and field trips.

**Rose Hill Environmental Club**

Email us at [[email protected]](/cdn-cgi/l/email-protection#592a3c3833193f362b3d313834773c3d2c)

**Lincoln Center Environmental Club**

Email us at [lcenvironmentalclub@fordham. edu](/cdn-cgi/l/email-protection#ea86898f849c83988584878f849e8b8689869f88aa8c85988e828b87c48f8e9f)