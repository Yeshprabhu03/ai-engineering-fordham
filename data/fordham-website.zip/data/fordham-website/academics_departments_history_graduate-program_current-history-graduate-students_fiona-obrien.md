https://www.fordham.edu/academics/departments/history/graduate-program/current-history-graduate-students/fiona-obrien

# Fiona O'Brien

![Fiona O'Brien](/media/home/departments-centers-and-offices/history/Fiona-OBrien_photo.jpg)



**Email:** [[email protected]](/cdn-cgi/l/email-protection#583e373a2a313d36696d183e372a3c303935763d3c2d)

**Research Interests:**

Early modern English and French reproductive health history, pregnancy and childbirth, ritual and healthcare

-
MA, University of Toronto

BA, University of Toronto

-
- Forthcoming: “Qui Numquam Fallit, Probatum Est: A Comparison of Fertility and Birth Rituals in the Late Middle Ages to Remedy in the Early Modern Period,” Graduate Student Voices Conference, Boston College [April 2025]
- “Our Groans to God: The Synching of Sensory and Emotional Experience During the Early Modern Birth Process,” Fifteenth Annual CUNY Graduate Center Conference, City University of New York [March 2025]
- “Her ‘Frigid Herbs’: Women’s Identities and Reproductive Health Networks in Early Modern English Receipt Books,” Humanist Principles in Early Modern Europe, Centre for Renaissance and Reformation Studies & University of Toronto [March 2023]

-
Loyola New Student Distinguished Fellowship, 2024-2025Folger Scholarly Programs Fellowship, 2024-2025