https://www.fordham.edu/academics/departments/history/oconnell-initiative

# O'Connell Initiative

## O’Connell Initiative on the Global History of Capitalism

The O’Connell Initiative for the Global History of Capitalism is a forum for intellectual exploration. It brings together scholars of every aspect of capitalism, from its earliest medieval manifestations to its twenty-first-century consequences across the globe. It supports groundbreaking research and teaching on global capitalism and engages with the public through lectures, debates, and workshops.

The O’Connell Initiative in the Global History of Capitalism is supported by generous gifts from Fordham alumnus Robert J. O’Connell, FCRH '65.