https://www.fordham.edu/academics/departments/history/undergraduate/undergraduate-resources

Being a History Undergraduate

Information on how to declare a major or minor in history

Information on how to request a letter of recommendation

Important forms

Research Resources

Primary sources

Primary Sources

Important resources at the library