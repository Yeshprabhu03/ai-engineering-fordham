https://www.fordham.edu/academics/departments/international-political-economy-and-development/graduate-program-in-international-political-economy-and-development/financial-aid/scholarships-for-practical-training

# Scholarships for Practical Training

![IPED students on a study tour](/media/home/departments-centers-and-offices/international-political-economy-and-development/Study_Tours_1_MD.jpeg)

Once enrolled in the IPED program, you will become eligible for additional scholarships that will help you prepare for the job market through the following fellowships.

[Intern Fellowships](/academics/departments/international-political-economy-and-development/graduate-program-in-international-political-economy-and-development/academics/ma-program/practical-training/internships/)- Overseas Study Tours:
[Language Immersion Study Awards](/academics/departments/international-political-economy-and-development/graduate-program-in-international-political-economy-and-development/academics/ma-program/practical-training/language-immersions/)[International Peace and Development Travel Program](/academics/departments/international-political-economy-and-development/graduate-program-in-international-political-economy-and-development/academics/ma-program/practical-training/international-peace-and-development-travel-program/)

Additional information can be obtained by contacting the IPED office at:

Fordham | IPED

The Graduate Program in International Political Economy and Development

Fordham University

Dealy Hall, Room E-517

441 E. Fordham Road

Bronx, New York 10458

USA

Tel: 718-817-4064

Fax: 718-817-4565

Email: [[email protected]](/cdn-cgi/l/email-protection#2f465f4a4b6f49405d4b474e42014a4b5a)