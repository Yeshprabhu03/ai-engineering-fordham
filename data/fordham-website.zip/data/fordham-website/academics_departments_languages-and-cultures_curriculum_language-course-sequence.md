https://www.fordham.edu/academics/departments/languages-and-cultures/curriculum/language-course-sequence

# Language Course Sequence

All students interested in studying a foreign language at Fordham University may choose either to continue the language studied previously or to begin a new one. Course sequence differ depending on the foreign language students wishes to take.