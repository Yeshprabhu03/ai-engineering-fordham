https://www.fordham.edu/academics/departments/languages-and-cultures/faculty/alessandro-polcri

# Alessandro Polcri

## PhD

SPRING 2026 office hours:

T&:F 9:00-10:00, T: 2:15-3:15, and by appt. (via Zoom)

-
B.A., Università di Firenze (Italy)


Ph.D., Yale University -
Comparative Literature

-
ITAL 2001


B.A., Università di Firenze (Italy)

Ph.D., Yale University

Comparative Literature

ITAL 2001