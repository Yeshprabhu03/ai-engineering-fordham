https://www.fordham.edu/academics/departments/math-and-computer--information-sciences/faculty

# Math and Computer & Information Sciences Faculty

Mathematics and Computer & Information Sciences program courses are taught by [mathematics](/academics/departments/mathematics/) and [computer and information sciences](https://www.fordham.edu/info/20344/computer_and_information_science) faculty members.

### Advisors

**Lincoln Center**

P. McFaddin, Lowenstein 808F, 212-636-6363

A. Werschulz, Lowenstein 815D, 212-636-6325

**Rose Hill**

C. Poor, John Mulcahy Hall 416, 718-817-3230

X. Zhang, John Mulcahy Hall 338, 718-817-4484