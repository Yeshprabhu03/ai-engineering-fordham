https://www.fordham.edu/academics/departments/medieval-studies/events/conferences

# Medieval Studies Conferences

### Publications from the Medieval Studies Conferences

### Upcoming Conferences

### Past Conferences

[50th Annual Byzantine Studies Conference in NYC (October 27, 2024)](https://mvstconference.ace.fordham.edu/bsana2024/)

[Courtly Literature: The Next Generation (March 1-3, 2024)](https://mvstconference.ace.fordham.edu/courtlyliterature/)

[Lost and Found: The Legacies of Greek Culture in the Global Middle Ages (March 4-5, 2023)](https://mvstconference.ace.fordham.edu/lostandfound/)

[Cultures of Exchange: Mercantile Mentalities Between Italy and the World (March 26-27, 2022)](https://mvstconference.ace.fordham.edu/culturesofexchange/)

[Medieval French Without Borders (March 20-21, 2021)](http://mvstconference.ace.fordham.edu/medievalfrenchwithoutborders/)

[Ritual and Religion in the Medieval World (March 30-31, 2019)](https://mvstconference.ace.fordham.edu/ritualandreligion/)

[Inside Out: Dress and Identity in the Middle Ages (March 17-18, 2018)](https://mvstconference.ace.fordham.edu/MVSTconf2018/)

[The Generative Power of Tradition: A Celebration of Traditio, 75 Years (March 25, 2017)](https://traditioconference.wordpress.com/)

[Manuscript as Medium (March 5-6 2016)](https://mvstconference.ace.fordham.edu/msasmedium/)

Europe After Wyclif (June 4-6, 2014)