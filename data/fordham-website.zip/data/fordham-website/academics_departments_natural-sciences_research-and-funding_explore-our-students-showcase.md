https://www.fordham.edu/academics/departments/natural-sciences/research-and-funding/explore-our-students-showcase

# Explore Our Student's Showcase

## Celebrate the accomplishments of our students through their poster presentations, symposium talks, and conference participation.

#### Celebrate the accomplishments of our students through their poster presentations, symposium talks, and conference participation.


#### Poster Symposium for Undergraduate Research

The annual Mary G. Hamilton Research Symposium is an opportunity for undergraduate students to present what they have learned through their research experiences in the Natural Science Department to the Fordham campus community.

**The symposium usually takes place in the Fall. **