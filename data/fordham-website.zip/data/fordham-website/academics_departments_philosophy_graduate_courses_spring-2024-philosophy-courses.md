https://www.fordham.edu/academics/departments/philosophy/graduate/courses/spring-2024-philosophy-courses

# Spring 2024 Philosophy Courses

PHIL 6105 - [Metaphysical Themes in Duns Scotus](https://bulletin.fordham.edu/search/?search=PHIL+7076)

W 12:00-2:00 p.m.

(Pini)

M

PHIL 6850 - [Hermeneutics](https://bulletin.fordham.edu/search/?search=PHIL+6850)

F 2:30-4:30 p.m.

(Crina)

F

PHIL 7076 - [Laws of Nature](https://bulletin.fordham.edu/search/?search=PHIL+6105)

M 2:30-4:30 p.m.

(Tan)

CA

PHIL 6106 - [Autonomy and Paternalism](https://bulletin.fordham.edu/search/?search=PHIL+6106)

R 3:15-5:15 p.m.

(Specker-Sullivan)

CO

PHIL 5209 - [Ancient Philosophy](https://bulletin.fordham.edu/search/?search=PHil+5209)

R 1:30-3:00 p.m.

(Johnson)

A

PHIL 5010 - [Introduction to St. Thomas Aquinas](https://bulletin.fordham.edu/search/?search=PHIL+5010)

W 6:00-8:00 p.m.

(Davies)

Med

PHIL 5005 - [Classical Modern Philosophy](https://bulletin.fordham.edu/search/?search=PHIL+5005)

M 10:00 a.m. - 12:00 p.m.

(Kopajtic)

M

PHIL 5100 - [Logic](https://bulletin.fordham.edu/search/?search=PHIl+5100)

M 12:15 p.m. - 2:15 p.m.

(Tan)

Logic requirement

PHIL 8070 - [Professional Writing Seminar](https://bulletin.fordham.edu/search/?search=PHIL+8070)

M 5:00 p.m. - 7:00 p.m.

(Tan)

PHIL 8001 - [Philosophy Education](https://bulletin.fordham.edu/search/?search=PHIL+8001)

F 12:15 p.m. - 2:15 p.m.

(Crina)

PHIL 8050 - [Philosohy Research/Writing](https://bulletin.fordham.edu/search/?search=PHIL+8001)

R 10:00 a.m. - 12:00 p.m.

(Winegar)



**A** = ancient; AN **Med** = medieval; **M** = modern; **CA** = contemporary analytic; **CC** = contemporary continental; **CO** = contemporary other