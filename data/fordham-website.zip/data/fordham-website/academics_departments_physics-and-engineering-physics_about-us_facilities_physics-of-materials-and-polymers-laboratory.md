https://www.fordham.edu/academics/departments/physics-and-engineering-physics/about-us/facilities/physics-of-materials-and-polymers-laboratory

# Physics of Materials and Polymers Laboratory

The Physics of Materials and Polymers Laboratory is essential to the department with equipment such as:

- Fourier Transform Infra-Red spectrometer used for analysis of molecules and polymers
- Fume hood for design and synthesis of novel materials
- Microscope and optical table with lasers
- X-Ray machine for structural analysis