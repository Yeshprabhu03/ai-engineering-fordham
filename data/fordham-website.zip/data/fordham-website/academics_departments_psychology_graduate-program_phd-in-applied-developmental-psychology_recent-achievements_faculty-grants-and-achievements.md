https://www.fordham.edu/academics/departments/psychology/graduate-program/phd-in-applied-developmental-psychology/recent-achievements/faculty-grants-and-achievements

Faculty Grants and Achievements
Hoyt, L. T. "Puberty and Sociocultural Experiences among Mexican-American Boys ", NSF
Brown, J. " Testing the Integration of an Empirically supported Teacher Consultation Model and a Social-emotional Learning and Literacy Intervention in Urban Elementary Schools", IES
Brown, J. " The Impact of School and Classroom Environments on Youth Mental Health: Moderation by Genetic Polymorphisms ", William T. Grant Foundation
Fisher, C. " Ethics in HIV Prevention Research Involving LGBT Youth", NIH
Yip, T. " The Effects of Racial Discrimination and Sleep Disturbance on Health and Academic Outcomes among Minority Youth ", NSF
Yip, T. " The Effects of Racial Discrimination and Sleep Disturbance on Health and among Chinese Youth", NIH
Fisher, C., "Increasing American Indian Alaskan Native research engagement through a culturally adapted ethics training", NIH