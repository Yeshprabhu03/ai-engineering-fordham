https://www.fordham.edu/academics/departments/religious-studies/steering-committee-members

# Religious Studies Steering Committee Members

In addition to the faculty of the theology department being available to the religious studies program, members of other department are available:

Professor Ed Bristow (History)[Professor John Andrew Foster (Classics)](/academics/departments/classics/classics-faculty-and-contacts/)[Professor John Seitz (Theology)](/academics/departments/theology/faculty/john-c-seitz/)