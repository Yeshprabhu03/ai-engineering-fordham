https://www.fordham.edu/academics/departments/sociology-and-anthropology/faculty/emeritusemerita-faculty/john-j-macisco-jr

# John J. Macisco, Jr.

Professor Emeritus of Sociology

Email: [[email protected]](/cdn-cgi/l/email-protection#7c111d1f150f1f133c1a130e18141d1152191809)

Office: Dealy Hall 403B

Phone: 718-817-3850

Fax: 718-817-3846

-
BA, MA, Fordham;


PhD, Brown, 1966 -
Migration; labor migration; research design.

-
Powers, Mary G., and John J. Macisco, Jr. 1994.

*The Immigration Experience in the United States: Policy Implications*. Center for Migration Studies, New York.Elizaga, Juan C., and John J. Macisco, Jr. 1975.

*Migraciones Internas: Teoría, Método y Factores Sociológicas*. Centro Latinoamericano de Demografía (CELADE), Santiago de Chile.Macisco, John J., Jr. 1975.

*Migrants to Metropolitan Lima: A Case Study*. Centro Latinoamericano de Demografía (CELADE), Santiago de Chile. -
Macisco, John J., Jr. 1992. "International migration: issues and research needs." In

*Migration, Population Structure, and Redistributive Policies*, Calvin Goldscheider, ed., Westview, Boulder, CO.Diaz-Briquets, Sergio, and John J. Macisco, Jr. 1986. "Population Growth and Emigration in Latin America: What is the Nature of the Relationship?" In

*Population Growth in Latin America and U.S. National Security*, John Saunders, ed. Allen & Unwin, Winchester, MA.Macisco, John J., Jr., and George C. Myers. 1975. "Fertility and migration,"

*International Migration Review*9:111-121.Weller, Robert H., John J. Macisco, Jr., and George R. Martine. 1971. "The Relative Importance of the Components of Urban Growth in Latin America,"

*Demography*8(2):225-232.