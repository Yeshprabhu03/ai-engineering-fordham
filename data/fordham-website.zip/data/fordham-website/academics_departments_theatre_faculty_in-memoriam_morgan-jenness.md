https://www.fordham.edu/academics/departments/theatre/faculty/in-memoriam/morgan-jenness

# Morgan Jenness

![Morgan Jenness](/media/home/departments-centers-and-offices/theatre/Morgan-Jenness.jpg)

[[email protected]](/cdn-cgi/l/email-protection)

212-636-6303

Lowenstein 423

Classes Taught

Theatre History

About

Morgan Jenness spent more than a decade at the New York Shakespeare Festival/Public Theater, with both Joseph Papp and George C. Wolfe, in various capacities such as literary manager, director of play development, and associate producer. She was also associate artistic director at the New York Theater Workshop and an associate director at the Los Angeles Theater Center.

She has served on peer panels for various funding institutions, including NYSCA and the NEA with whom she served as a site evaluator for almost a decade. Jenness was the creative director for the Helen Merrill Ltd. agency for many years, and she currently holds a position in the Literary Department at Abrams Artists Agency.

In 2003, Jenness was presented with an Obie Award Special Citation for Longtime Support of Playwrights.