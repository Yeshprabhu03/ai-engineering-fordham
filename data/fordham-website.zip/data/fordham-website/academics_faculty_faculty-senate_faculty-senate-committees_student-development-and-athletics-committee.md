https://www.fordham.edu/academics/faculty/faculty-senate/faculty-senate-committees/student-development-and-athletics-committee

# Student Development and Athletics Committee

Charged with monitoring the educational experience of students outside the classroom, including the Athletics program of the University. Two-year renewable terms.

| Judith Jones |
|

Charged with monitoring the educational experience of students outside the classroom, including the Athletics program of the University. Two-year renewable terms.

| Judith Jones |
|