https://www.fordham.edu/academics/faculty/faculty-senate/faculty-senate-committees/university-tenure-review-committee

# University Tenure Review Committee

Maximum of one three-year term. One department member. 10 tenured faculty members: 4 FCRH, 2 FCLC, 1 Gabelli, 1 GSE, 1 GSS with a fourth rotating professional school beginning with Gabelli in Spring 1998. Runs on **Calendar** Year.

|
Christopher Aubin |
|

Jemel Aguilar