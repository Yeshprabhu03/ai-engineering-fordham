https://www.fordham.edu/academics/research/libraries-and-collections/journals-published-at-fordham

# Journals Published at Fordham

![FURJ](/media/review/content-assets/migrated/images/FURJ_Submissions.jpg)

### English Department

### Law School

[Fordham Environmental Law Review](https://ir.lawnet.fordham.edu/elr/)[Fordham Intellectual Property, Media and Entertainment Law Journal](http://www.fordhamiplj.org/)[Fordham International Law Journal](https://www.fordhamilj.org/)[Fordham Journal of Corporate and Financial Law](http://news.law.fordham.edu/jcfl/)[Fordham Law Review](http://fordhamlawreview.org/)[Fordham Urban Law Journal](http://urbanlawjournal.com/)

### Medieval Studies Program

[TRADITIO:](/academics/research/libraries-and-collections/journals-published-at-fordham/traditio/)Studies in Ancient and Medieval Thought, History, and Religion

### Philosophy Department

- International Philosophical Quarterly
- New Nietzsche Studies
- Journal of Neoplatonic Studies