https://www.fordham.edu/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/mcgannon-center/events-and-news/antisocial-media-facebook-and-the-future-of-democracy

# AntiSocial Media: Facebook and the Future of Democracy

![Siva Vaidhyanathan](/media/review/content-assets/migrated/images/Screen_Shot_2020_06_15_at_5.03.03_PM.png)

Join us at 5 p.m. on Thursday, October 4 at the Skadden Conference Center at Fordham Law for our special event “AntiSocial Media: Facebook and the Future of Democracy.”

Siva Vaidhyanathan, author of * Antisocial Media: How Facebook Disconnects Us and Undermines Democracy, *will discuss how Facebook devolved from an innocent social site into a force that makes democracy a lot more challenging.

The event will also feature Julia Angwin, award-winning investigative journalist, formerly of ProPublica and *The Wall Street Journal; *Danielle Keats Citron,Visiting Professor of Law at Fordham Law School and Morton & Sophia Macht Professor of Law at Maryland University; and McGannon Center Director Olivier Sylvain.

Check-in begins at 5 p.m., with the program commencing at 5:30 p.m. Reception to follow.