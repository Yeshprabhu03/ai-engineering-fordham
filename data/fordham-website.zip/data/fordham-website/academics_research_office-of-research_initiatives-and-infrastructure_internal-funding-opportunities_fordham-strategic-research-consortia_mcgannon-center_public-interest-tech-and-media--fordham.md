https://www.fordham.edu/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/mcgannon-center/public-interest-tech-and-media--fordham

# Public Interest Tech and Media @ Fordham

## PITM@Fordham

The McGannon Center is home to Fordham faculty’s work in Public Interest Technology + Media (PITM).

Fordham is one of 58 members of the [Public Interest Technology University Network,](https://pitcases.org/) a New America Foundation sponsored consortium dedicated to furthering research about Public Interest Tech and preparing students to work in PIT-related careers.

Fordham students and faculty are particularly well-situated to lead in the field of Public Interest Technology, as our commitment to ethics and social justice imbues our teaching and scholarship.