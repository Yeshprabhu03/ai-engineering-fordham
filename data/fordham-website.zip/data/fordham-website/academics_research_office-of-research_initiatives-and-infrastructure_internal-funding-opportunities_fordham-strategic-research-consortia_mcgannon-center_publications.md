https://www.fordham.edu/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/mcgannon-center/publications

# Publications for The McGannon Center

![McGannon Logo](/media/review/content-assets/migrated/images/Logo_Export_MCF001_14__4__1.png)

The McGannon Center publishes a variety of whitepapers and reports. We also sponsor a book series with Fordham University Press.

The McGannon Center publishes a variety of whitepapers and reports. We also sponsor a book series with Fordham University Press.