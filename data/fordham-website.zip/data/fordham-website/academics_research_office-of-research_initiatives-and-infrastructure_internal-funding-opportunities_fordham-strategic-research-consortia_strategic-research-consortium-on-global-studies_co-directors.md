https://www.fordham.edu/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/strategic-research-consortium-on-global-studies/co-directors

# Co-Directors

Dr. [Yuko Miki](/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/strategic-research-consortium-on-global-studies/co-directors/yuko-miki/), Associate Professor and Associate Director of Latin American and Latinx Studies (LALSI), History Department, Arts and Sciences

Dr. [Fuhua Zhai](/academics/research/office-of-research/initiatives-and-infrastructure/internal-funding-opportunities/fordham-strategic-research-consortia/strategic-research-consortium-on-global-studies/co-directors/fuhua-zhai/), Professor and Thea Bowman Endowed Chair in Social Research, Graduate School of Social Service