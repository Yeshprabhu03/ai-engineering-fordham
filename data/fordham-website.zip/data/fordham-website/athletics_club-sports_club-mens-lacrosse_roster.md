https://www.fordham.edu/athletics/club-sports/club-mens-lacrosse/roster

# Roster

2023-2024 Club Men's Lacrosse Roster

| Name | Class | High School | Hometown |
|---|---|---|---|
| Leo Anderson | Senior | Hingham High School | Hingham, MA |
| Jackson Barberis | Freshman | Vernon Hills High School | Vernon Hills, IL |
| Cooper Barlow | Junior | IMG Academy | Guilford, CT |
| John Barry | Sophomore | St. Sebastian High School | Sharon, MA |
| William Borg | Freshman | Bergen Catholic High School | Tenafly, NJ |
| Jackson Brooks | Freshman | Evergreen High School | Evergreen, CO |
| Joseph Bubay | Senior | Morris Knolls High School | Parsippany, NJ |
| Ishan Chauhan | Junior | MICDS | St. Louis, Missouri |
| Joshua Chung | Freshman | Syosset High School | Syosset, NY |
| Daniel Cullinan | Sophomore | Fairfield Warde High School | Fairfield, CT |
| Cooper Dionne | Senior | Ridgewood High School | Ridgewood, NJ |
| Benjamin Farahbod | Freshman | The Kinkaid School | Houston, TX |
| Callum Feeney | Freshman | Hastings High School | Hastings On Hudson, NY |
| Nicholas Fidacaro | Junior | Mountain Lakes High School | Mountain Lakes, NJ |
| Aidan Fullem | Junior | Ridgewood High School | Ridgewood, NJ |
| Carlo Giso | Freshman | Stillwater High School | Saratoga Springs, NY |
| Ben Griffin | Freshman | Garden City High School | Garden City, NY |
| Bryan Hekemian | Sophomore | Saddle River Day | Ho-Ho-Kus, NJ |
| Michael Howard | Sophomore | Sachem North High School | Holbrook, New York |
| Ryan Jackson | Junior | Wilton High School | Wilton, CT |
| Aiden Kerr | Sophomore | Walton High School | Atlanta, GA |
| Max Knight | Junior | Darien High School | Darien, CT |
| Brendan Lawless | Senior | Medfield High School | Medfield, MA |
| Thomas Lucas | Junior | Saint Joseph's High School | Norwalk, CT |
| Bobby Lynch | Senior | Ridgewood High School | Ridgewood, NJ |
| Donald Mack | Junior | Manhasset Secondary School | Manhasset, NY |
| Buck Mahoney | Freshman | Darien High School | Darien, CT |
| Dylan Mayo | Sophomore | Bergen Catholic High School | Washington Township, NJ |
| Michael McCartin | Junior | Tabor Academy | Barnstable, MA |
| Cole McCrickard | Junior | Saddle River Day School | Carlstadt, NJ |
| Henry Melconian | Freshman | Lawrenceville High School | Red Bank, NJ |
| Zachary Mooers | Junior | Cherry Creek High School | Englewood, CO |
| Thomas Morris | Freshman | The Lawrenceville School | Yardley, PA |
| Mike Morris | Senior | The Lawrenceville School | Yardley, PA |
| Cambell Morrison | Freshman | The Governors Academy | Andover MA |
| Matt Morrissey | Freshman | Bergen Catholic High School | Saddle River, NJ |
| Andrew O'Loughlin | Senior | Staples High School | Westport, CT |
| Colin O'Shea | Freshman | Ramapo High School | Wyckoff, NJ |
| Cooper Barlow | Freshman | Guilford High School | |
| James Othmer | Senior | Mahopac High School | Mahopac, NY |
| Ari Patel | Freshman | Collins Hill High School | Atlanta, GA |
| Micheal Rawson | Senior | Boston College High School | Boston, MA |
| Patrick Riddle | Sophomore | Red Bank Regional High School | Little Silver, NJ |
| Trey Rodriguez | Junior | Mount Sinai High School | Mount Sinai, NY |
| Dante Rosalina | Junior | Saint Ignatius High School | Cleveland, Ohio |
| John Scarlata | Senior | Greenwich High School | Greenwich, CT |
| Theodore Shimaitis | Junior | Fairfield Warde High School | Fairfield, CT |
| Samuel Smith-Ackerly | Freshman | Montgomery Blair High School | Takoma Park, MD |
| Gavin Stanek | Sophomore | Pittsburgh Central Catholic High School | Pittsburgh, PA |
| Liam Stewart | Junior | Saint Ignatius College Prep School | Chicago, IL |
| Evan Tritt | Senior | Notre Dame High School | Hamilton, NJ |
| Rafferty Waterson | Sophomore | Mira Costa High School | Manhattan Beach, CA |
| Jonathan Windover | Senior | Canandaigua High School | Canandaigua, NY |