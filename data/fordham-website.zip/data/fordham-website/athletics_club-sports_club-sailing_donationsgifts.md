https://www.fordham.edu/athletics/club-sports/club-sailing/donationsgifts

# Donations/Gifts

## Fordham Club Sailing Donations and Gifts

![Fordham Ram Logo](/media/review/content-assets/migrated/images/fordham_ram.jpg)

Stay Updated

[Update Your Contact Information](http://forever.fordham.edu/s/1362/rd/index.aspx?sid=1362&gid=1&pgid=94&cid=256%23/PersonalProfile)

Fill in your contact information to receive regular updates from the Office of Alumni Relations.

Interested in Giving a Gift to Fordham Sailing?

[Make a Gift](https://securelb.imodules.com/s/1362/rd/index.aspx?sid=1362&gid=1&pgid=603&cid=1881)

Select the Fund Category "Athletics"

Select the Fund "Club Sports - "Sailing"

If Alumni are interested in connecting with the current Fordham Club Sailing players, contact the President of Fordham Club Sailing, who is responsible for Alumni Relations.