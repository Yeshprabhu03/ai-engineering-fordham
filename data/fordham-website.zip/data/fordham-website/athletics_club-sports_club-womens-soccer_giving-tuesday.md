https://www.fordham.edu/athletics/club-sports/club-womens-soccer/giving-tuesday

# Women's Soccer Giving Tuesday

Dear Friends and Family,

As we approach this season of giving, we want to take a moment to express our heartfelt gratitude for everything you’ve done to make our team stronger, more successful, and filled with joy. The love and support from each of you has been nothing short of amazing. You are a vital part of our incredible Ramily!

As we continue to grow, we rely on the generosity of our supporters to help us achieve even more. This **Giving Tuesday **help us reach our goal of $800 to support the costs of new uniforms and balls!

Every contribution—big or small—makes a difference, and we are grateful for whatever you can give. If you’re able, please consider making a donation today to help us reach our goal and continue building the strength and spirit of our Ramily.

To donate, use our [Giving Tuesday link! ](https://give.fordham.edu/athletics-giving-tuesday-2024)

Thank you once again for your unwavering support, and for being an essential part of our journey.

With gratitude,

Women's Club Soccer

![](/media/home/departments-centers-and-offices/athletics/Screenshot-2024-11-14-at-3.56.25-PM.png)