https://www.fordham.edu/fordham-college-at-lincoln-center/about/board-of-advisors

# FCLC Board of Advisors

Fordham College at Lincoln Center convenes a Board of Advisors. Composed of alumni and friends of the College, many of whom have already made a meaningful impact on the University, the Board advises the Dean on the goals and priorities of FCLC and helps to realize the vision of FCLC as a premier liberal arts college in Manhattan.

MEMBERSHIP

- Maureen Beshar FCLC ’86
- Cathy Blaney FCLC ’86
- Jolie Ann Calella FCLC ’91
- Rick Calero FCLC ’90
- Patricia Dugan Perlmuth FCLC ’79
- Roxanne Garcia FCLC '08
- Jalen Glenn, FCLC '16, GSB '22
- Scot Hoffman FCLC '98
- Andrew Snyder, FCLC '03
- Jonathan Valenti FCLC ’98
- Mark Luis Villamar GSB ’69