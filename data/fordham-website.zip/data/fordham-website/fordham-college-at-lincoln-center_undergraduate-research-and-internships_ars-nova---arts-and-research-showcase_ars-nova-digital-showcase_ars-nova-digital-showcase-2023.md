https://www.fordham.edu/fordham-college-at-lincoln-center/undergraduate-research-and-internships/ars-nova---arts-and-research-showcase/ars-nova-digital-showcase/ars-nova-digital-showcase-2023

Sophie Chen

Feasibility of Artificial Intelligence based Telemedicine in Age-Related Macular Degeneration (AMD)