https://www.fordham.edu/fordham-college-at-lincoln-center/undergraduate-research-and-internships/ars-nova---arts-and-research-showcase/ars-nova-showcase-and-participants

2025 Participants

2024 Participants

2023 Participants

2022 Participants

2021 Participants

2020 Participants