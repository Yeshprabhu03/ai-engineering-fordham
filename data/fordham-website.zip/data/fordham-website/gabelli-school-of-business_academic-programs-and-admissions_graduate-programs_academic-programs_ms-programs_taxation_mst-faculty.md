https://www.fordham.edu/gabelli-school-of-business/academic-programs-and-admissions/graduate-programs/academic-programs/ms-programs/taxation/mst-faculty

# M.S.T. Faculty

[Kelly Ulto](/gabelli-school-of-business/faculty/full-time-faculty/kelly-ulto/), M.B.A., CPA

*Clinical Associate Professor**Program Director*

[Professor Ulto's full biography, research interests, and publications.](/gabelli-school-of-business/faculty/full-time-faculty/kelly-ulto/)

[Iris Schneider](/gabelli-school-of-business/faculty/full-time-faculty/iris-schneider/), J.D., CPA

*Clinical Associate Professor*

[Professor Schneider's full biography, research interests, and publications.](/gabelli-school-of-business/faculty/full-time-faculty/iris-schneider/)