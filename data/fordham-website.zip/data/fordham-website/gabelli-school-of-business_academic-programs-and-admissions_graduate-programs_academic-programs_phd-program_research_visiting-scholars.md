https://www.fordham.edu/gabelli-school-of-business/academic-programs-and-admissions/graduate-programs/academic-programs/phd-program/research/visiting-scholars

# Visiting Scholars

The Gabelli School Ph.D. program has welcomed several internationally renowned researchers to join the program for seminars and lectures. These visiting scholars have provided our doctoral students with invaluable exposure to some of the most exciting contemporary research in the study of business.

**Renée Adams**, Saïd Business School, University of Oxford

**Tom Chemmanur**, Carroll School of Management, Boston College

**Gonul Colak**, Hanken School of Economics

**Kose John**, Stern School of Business, NYU

**Kai Li**, Sauder School of Business, University of British Columbia

**Ron Masulis**, UNSW Business School, University of New South Wales

**Vikas Mehrotra**, Alberta School of Business, University of Alberta

**Anthony Saunders**, Stern School of Business, NYU

**Kenneth Simons**, Rensselaer Polytechnic Institute

**Sascha Steffen**, Frankfurt School of Finance and Management

**Gaiyan Zhang**, University of Missouri–St. Louis