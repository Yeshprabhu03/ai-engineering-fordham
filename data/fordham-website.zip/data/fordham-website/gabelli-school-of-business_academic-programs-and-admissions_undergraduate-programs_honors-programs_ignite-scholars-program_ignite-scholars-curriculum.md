https://www.fordham.edu/gabelli-school-of-business/academic-programs-and-admissions/undergraduate-programs/honors-programs/ignite-scholars-program/ignite-scholars-curriculum

# Ignite Scholars Curriculum

Ignite Scholars enroll in honors-level sections of select business and liberal arts core courses. These courses are designed to hone students’ ability to thrive in ambiguous and confusing business situations, identify and analyze problems, and develop innovative solutions.

Freshman-year honors sectionsThe Ground Floor

Composition II

Ignite Scholars Readings

Careers Integrated Project

Social Innovation Integrated Cohort*

Strategy

Capstone Project I – III

*All Gabelli School sophomores have the chance to express interest in a version of the sophomore business core that is focused on social innovation: using business approaches to find solutions for problems that face society. These “social innovation cohorts” have special relevance to the mission of the Ignite Scholars Program, so scholars complete the sophomore-year business core as a member of one of these cohorts.