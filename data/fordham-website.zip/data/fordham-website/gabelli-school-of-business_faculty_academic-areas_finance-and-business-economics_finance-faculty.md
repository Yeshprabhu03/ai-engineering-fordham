https://www.fordham.edu/gabelli-school-of-business/faculty/academic-areas/finance-and-business-economics/finance-faculty

# Finance Faculty

![Gabelli Faculty teaching a class](/media/home/schools/gabelli-school-of-business/gsb_faculty_2.jpg)

[Victor Marek Borun](/gabelli-school-of-business/faculty/full-time-faculty/victor-marek-borun/)

Emeritus Professor [[email protected]](/cdn-cgi/l/email-protection#6d0f021f18032d0b021f09050c0043080918)

[Nusret Cakici](/gabelli-school-of-business/faculty/full-time-faculty/nusret-cakici/)

Professor

Felix E. Larkin Distinguished Professorship in Finance[[email protected]](/cdn-cgi/l/email-protection#ea898b81838983aa8c85988e828b87c48f8e9f)

[Sris Chatterjee](/gabelli-school-of-business/faculty/full-time-faculty/sris-chatterjee/)

Professor

Gabelli Chair in Global Security Analysis[[email protected]](/cdn-cgi/l/email-protection#56153e37222233243c333316303924323e373b78333223)

[Michael Cheah](/gabelli-school-of-business/faculty/full-time-faculty/michael-cheah/)

Associate Clinical Professor[[email protected]](/cdn-cgi/l/email-protection#a3dac0cbc6c2cbe3c5ccd1c7cbc2ce8dc6c7d6)

[Ren-Raw Chen](/gabelli-school-of-business/faculty/full-time-faculty/ren-raw-chen/)

Professor[[email protected]](/cdn-cgi/l/email-protection#f88a9b909d96b89e978a9c909995d69d9c8d)

[N. K. Chidambaran](/gabelli-school-of-business/faculty/full-time-faculty/nk-chidambaran/)

Professor and Associate Dean of Research and Faculty Development[[email protected]](/cdn-cgi/l/email-protection#a3c0cbcac7c2cec1c2d1c2cde3c5ccd1c7cbc2ce8dc6c7d6)

[Andrey Ermolov](/gabelli-school-of-business/faculty/full-time-faculty/andrey-ermolov/)

Professor

Felix E. Larkin Distinguished Professorship in Management[[email protected]](/cdn-cgi/l/email-protection#375652455a585b58410677515845535f565a19525342)

[John Finnerty](/gabelli-school-of-business/faculty/full-time-faculty/john-finnerty/)

Professor[[email protected]](/cdn-cgi/l/email-protection#bddbd4d3d3d8cfc9c4fddbd2cfd9d5dcd093d8d9c8)

[Robert George](/gabelli-school-of-business/faculty/full-time-faculty/robert-george/)

Assistant Professor[[email protected]](/cdn-cgi/l/email-protection#c7b5a0a2a8b5a0a287a1a8b5a3afa6aae9a2a3b2)

[Gautam Goswami](/gabelli-school-of-business/faculty/full-time-faculty/gautam-goswami/)

Professor[[email protected]](/cdn-cgi/l/email-protection#20474f5357414d4960464f524448414d0e454455)

[Iftekhar Hasan](https://www.fordham.edu/gabelli-school-of-business/faculty/full-time-faculty/iftekhar-hasan/)

University Professor

E. Gerald Corrigan Chair in International Business and Finance[[email protected]](/cdn-cgi/l/email-protection#dab3b2bba9bbb49abcb5a8beb2bbb7f4bfbeaf)

[Gayané Hovakimian](/gabelli-school-of-business/faculty/full-time-faculty/gayane-hovakimian/)

Professor and Area Chair[[email protected]](/cdn-cgi/l/email-protection#e48c8b92858f8d898d858aa4828b96808c8589ca818091)

[Yanki Kalfa](/gabelli-school-of-business/faculty/full-time-faculty/yanki-kalfa/)

Assistant Professor[[email protected]](/cdn-cgi/l/email-protection#64170f0508020524020b16000c05094a010011115f)

[Robert Kissell](/gabelli-school-of-business/faculty/full-time-faculty/robert-kissell/)

Associate Clinical Professor[[email protected]](/cdn-cgi/l/email-protection#6a18010319190f06062a0c05180e020b07440f0e1f51)

[Xiang Li](/gabelli-school-of-business/faculty/full-time-faculty/xiang-li/)

Assistant Professor

[Stefano Manfredonia](/gabelli-school-of-business/faculty/full-time-faculty/stefano-manfredonia/)

Assistant Professor[[email protected]](/cdn-cgi/l/email-protection#46352b27282034232229282f277706202934222e272b682322337d)

[Katherin Marton](/gabelli-school-of-business/faculty/full-time-faculty/katherin-marton/)

Professor[[email protected]](/cdn-cgi/l/email-protection#4825293a3c2726082e273a2c202925662d2c3d)

[James H. McCann](/gabelli-school-of-business/faculty/full-time-faculty/james-h-mccann/)

Senior Lecturer[[email protected]](/cdn-cgi/l/email-protection#97faf4f4f6f9f9d7f1f8e5f3fff6fab9f2f3e2)

[Paul D. McNelis](/gabelli-school-of-business/faculty/full-time-faculty/paul-mcnelis/)

Professor Emertius[[email protected]](/cdn-cgi/l/email-protection#214c424f444d485261474e534549404c0f444554)

[Kevin Mirabile](/gabelli-school-of-business/faculty/full-time-faculty/kevin-mirabile/)

Clinical Professor[[email protected]](/cdn-cgi/l/email-protection#a7caced5c6c5cecbc2e7c1c8d5c3cfc6ca89c2c3d2)

[Peter Mueller](/gabelli-school-of-business/faculty/full-time-faculty/peter-mueller/)

Assistant Professor [[email protected]](/cdn-cgi/l/email-protection#4838253d2d24242d3a7e082e273a2c202925662d2c3d)

[Natalia I. Reisel](/gabelli-school-of-business/faculty/full-time-faculty/natalia-i-reisel/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#ee809c8b879d8b82ae88819c8a868f83c08b8a9b)

[Yusif Simaan](/gabelli-school-of-business/faculty/full-time-faculty/yusif-simaan/)

Professor[[email protected]](/cdn-cgi/l/email-protection#d2a1bbbfb3b3bc92b4bda0b6bab3bffcb7b6a7)

[Qing Sheng](/gabelli-school-of-business/faculty/full-time-faculty/qing-sheng/)

Clinical Professor[[email protected]](/cdn-cgi/l/email-protection#ccbdbfa4a9a2abff8caaa3bea8a4ada1e2a9a8b9)

[Yi Tang](/gabelli-school-of-business/faculty/full-time-faculty/yi-tang/)

Professor[[email protected] ](/cdn-cgi/l/email-protection#205954414e4760464f524448414d0e454455051210)

[Lin Tong](/gabelli-school-of-business/faculty/full-time-faculty/lin-tong/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#c3afb7acada4f183a5acb1a7aba2aeeda6a7b6)

[Yihui Wang](/gabelli-school-of-business/faculty/full-time-faculty/yihui-wang/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#ed949a8c838adcd8dcad8b829f89858c80c3888998)

[Maya Waisman](/gabelli-school-of-business/faculty/full-time-faculty/maya-waisman/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#addaccc4dec0ccc3edcbc2dfc9c5ccc083c8c9d8)

[Frank M. Werner](/gabelli-school-of-business/faculty/full-time-faculty/frank-werner/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#e3859486918d8691a3858c91878b828ecd868796)

[Jiqiu "Rachel" Xiao](/gabelli-school-of-business/faculty/full-time-faculty/jiqiu-rachel-xiao/)

Assistant Professor[[email protected]](/cdn-cgi/l/email-protection#5c2e3d3f34393024353d331c3a332e38343d3172393829)

[Yuewu Xu](/gabelli-school-of-business/faculty/full-time-faculty/yuewu-xu/)

Associate Professor[[email protected]](/cdn-cgi/l/email-protection#add4d8d5d8edcbc2dfc9c5ccc083c8c9d8)

[An Yan](/gabelli-school-of-business/faculty/full-time-faculty/an-yan/)

Professor

Bendheim Chair[[email protected]](/cdn-cgi/l/email-protection#fe9f879f90be98918c9a969f93d09b9a8b)

[Xun Zhong](/gabelli-school-of-business/faculty/full-time-faculty/xun-zhong/)

Assistant Professor[[email protected]](/cdn-cgi/l/email-protection#3941435156575e0b08795f564b5d515854175c5d4c)