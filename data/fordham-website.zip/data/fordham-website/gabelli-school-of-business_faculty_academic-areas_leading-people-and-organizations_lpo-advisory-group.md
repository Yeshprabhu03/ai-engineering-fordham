https://www.fordham.edu/gabelli-school-of-business/faculty/academic-areas/leading-people-and-organizations/lpo-advisory-group

# LPO Advisory Group

The advisory board supports the Leading People and Organization (LPO) area in its quest to create and deliver the highest quality and highest impact education for the thoughtful, passionate and compassionate leadership student. To that end, the advisory board supports our efforts with regard to research (knowledge creation), teaching and outreach (knowledge dissemination).

![David Sloan Wilson](/media/review/content-assets/migrated/images/David_Sloan_Wilson.jpg)

Professor and President, Evolution Institute