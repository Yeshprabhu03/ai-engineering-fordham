https://www.fordham.edu/graduate-school-of-arts-and-sciences/student-resources/graduate-student-council/graduate-student-council-representatives

| Biological Sciences |
Nini Mamisashvili (cell/molecular track)
Laila Ouldibbat (cell/molecular track)
Brian Saville (ecology track) |
[[email protected]](/cdn-cgi/l/email-protection#c9a7a4a8a4a0baa8baa1bfa0a5a089afa6bbada1a8a4e7acadbc)
[[email protected]](/cdn-cgi/l/email-protection#80eceff5ece4e9e2e2e1f4c0e6eff2e4e8e1edaee5e4f5)
[[email protected]](/cdn-cgi/l/email-protection#0c6e7f6d7a656060694c6a637e68646d6122696879) |
| Computer Science |
Soubhagya Das |
[[email protected]](/cdn-cgi/l/email-protection#d7a4a4b3e697b1b8a5b3bfb6baf9b2b3a2) |
| Cybersecurity |
Nicholas Brana |
[[email protected]](/cdn-cgi/l/email-protection#a4cac6d6c5cac5e4c2cbd6c0ccc5c98ac1c0d1) |
| Data Science |
Ali Sadeghina |
[[email protected]](/cdn-cgi/l/email-protection#89e8fabdb9c9efe6fbede1e8e4a7ecedfc) |
| Economics |
Renier de Guzman |
[[email protected]](/cdn-cgi/l/email-protection#592b3d3c3e2c233438376c193f362b3d313834773c3d2c) |
| English |
Roxana Cuevas Cruz |
[[email protected]](/cdn-cgi/l/email-protection#601203565220060f120408010d4e050415) |
| Ethics and Society |
Eliane Victoria |
[[email protected]](/cdn-cgi/l/email-protection#b5d0c3dcd6c1dac7dcd4f5d3dac7d1ddd4d89bd0d1c0) |
| Health Administration |
Kenndi Pankey |
[[email protected]](/cdn-cgi/l/email-protection#e9828b99daa98f869b8d818884c78c8d9c) |
| History |
Owen Clow |
[[email protected]](/cdn-cgi/l/email-protection#e8878b84879fa88e879a8c808985c68d8c9d) |
| Humanitarian Studies |
Courtney Kren |
[[email protected]](/cdn-cgi/l/email-protection#e7848c958289a7818895838f868ac9828392) |
| International Humanitarian Action (MIHA) |
TBD |
TBD |
| International Political Economy and Development |
Samantha Ketter |
[[email protected]](/cdn-cgi/l/email-protection#0b7860393a3f4b6d64796f636a66256e6f7e) |
| International Students |
August Yu |
[[email protected]](/cdn-cgi/l/email-protection#0e62777b383a4e68617c6a666f63206b6a7b) |
| Medieval Studies |
Brittany Lugo |
[[email protected]](/cdn-cgi/l/email-protection#1476707854727b66707c75793a717061) |
| Philosophy |
Kenneth Bruce |
[[email protected]](/cdn-cgi/l/email-protection#e58e8797908680d0a5838a97818d8488cb808190) |
| Psychology |
Meryl Rueppel
Frankie Osso |
[[email protected]](/cdn-cgi/l/email-protection#a4c9d6d1c1d4d4c1c8e4c2cbd6c0ccc5c98ac1c0d1)
[[email protected]](/cdn-cgi/l/email-protection#11777e62627e51777e637579707c3f747564) |
| Public Media |
Con (Kiernan) Roche |
[[email protected]](/cdn-cgi/l/email-protection#8fece4fdbbcfe9e0fdebe7eee2a1eaebfa) |
| Theology |
Dakota Hampton |
[[email protected]](/cdn-cgi/l/email-protection#7a1e121b170a0e1514483a1c15081e121b17541f1e0f) |
| Urban Studies |
Christine Rong |
[[email protected]](/cdn-cgi/l/email-protection#7b180914151c493b1d14091f131a16551e1f0e) |