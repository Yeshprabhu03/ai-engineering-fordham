https://www.fordham.edu/graduate-school-of-arts-and-sciences/student-resources/professional-development/gsas-futures/contact-gsas-futures

# Contact GSAS Futures

GSAS Futures works with a team of campus partners to service your professional development and wellness needs. You are welcome to reach out at any time with questions or comments on upcoming events, ideas for new events or initiatives, and requests for assistance regarding career and emotional support.

Seoyoon Chang, Ed.D.

GSAS Assistant Dean for Student Professional Development[[email protected]](/cdn-cgi/l/email-protection#5c2f2829383932283b2f3d2f1c3a332e38343d3172393829)

[Delasia Rice](/resources/career-resources/career-center/about-us/meet-our-team/)

Graduate School Career Counselor

Graduate School Specialist | Professional Development | Career Counseling[[email protected]](/cdn-cgi/l/email-protection#6501170c0600545625030a17010d04084b000110)

[Deborah Lawrence](/student-life/safety-health-and-wellness/counseling-and-psychological-services/staff-and-trainees/), Ph.D.

Supervising Psychologist and Group Therapy Program Coordinator, Rose Hill Campus[Office of Counseling and Psychological Services](/student-life/safety-health-and-wellness/counseling-and-psychological-services/how-to-make-an-appointment/)[[email protected]](/cdn-cgi/l/email-protection#2f4b434e585d4a414c4a176f49405d4b474e42014a4b5a)