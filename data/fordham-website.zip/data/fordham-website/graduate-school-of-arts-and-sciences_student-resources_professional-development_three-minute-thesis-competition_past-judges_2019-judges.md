https://www.fordham.edu/graduate-school-of-arts-and-sciences/student-resources/professional-development/three-minute-thesis-competition/past-judges/2019-judges

# 2019 Judges

**John Bugg, Ph.D.**

Interim Chair and Director of Graduate Studies, English**Johanna Francis, Ph.D.**

Director of Graduate Studies, Economics**Stephen Grimm, Ph.D.**

Chair, Department of Philosophy**Lucian Lipinsky de Orlov, GSAS '18**

3MT® 2018 Winner**Jules Okafor**

Dean's Leadership Committee**Christina Rucinski, Ph.D. Candidate**

Applied Developmental Psychology/President, Graduate Student Association (AY 2018 - 2019)