https://www.fordham.edu/graduate-school-of-education/centers-and-institutes/the-center-for-catholic-school-leadership-and-faith-based-education/staff

# The Center for Catholic School Leadership and Faith-Based Education Staff

![Gerald Cattaro](/media/review/content-assets/migrated/images/5754_250x250.jpg)

**Gerald Cattaro, Ed.D.**

Professor and Executive Director [[email protected]](/cdn-cgi/l/email-protection#3c5f5d48485d4e537c5a534e58545d5112595849)

718-817-6420

Before joining the faculty, he was a principal for 18 years, a high school teacher, and a junior high school teacher. He currently serves on several international and national governing boards, editorial boards, and educational commissions. [Learn more about Gerald Cattaro](/graduate-school-of-education/faculty/gerald-m-cattaro/).

## Contact

The Center for Catholic School Leadership and Faith-Based Education

Lowenstein 1024

113 West 60th Street

New York, NY 10023