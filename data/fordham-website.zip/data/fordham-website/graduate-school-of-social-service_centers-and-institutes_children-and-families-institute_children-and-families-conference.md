https://www.fordham.edu/graduate-school-of-social-service/centers-and-institutes/children-and-families-institute/children-and-families-conference

# Children and Families Conference

**** Please check back for upcoming conferences! ****


**Previous Sponsors **

- Fordham University Children and Families Institute for Research, Support, and Training
- Fordham University Ravazzin Center on Aging
- New York State Intergenerational Network (Westchester Chapter)
- Westchester County Livable Communities Intergenerational Collaborative

**Past Conferences**

- A Time of Crisis: Health and Wellness Across All Generations - June 24, 2020
- Practice Across the Lifespan: Intergenerational Work in Action - March 9, 2016
- Autism Spectrum Disorders: Working with Individuals and Families throughout the Lifespan - April 4, 2014
- Enhancing Mental Well-Being of Children, Youth, and Families - March 27, 2013
- Preventing and Reducing Adolescent Substance Abuse - April 4, 2012