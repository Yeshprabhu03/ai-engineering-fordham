https://www.fordham.edu/info/20936/themeli@fordham.edu

# Faculty

-
Alan Anderson


Lecturer

Ph.D., Fordham University

Rose Hill, Dealy E-543[[email protected]](/cdn-cgi/l/email-protection#187979767c7d6a6b77762e587e776a7c707975367d7c6d)

718-817-4048[Mary Burke](/academics/departments/economics/faculty/mary-burke/)

Senior Lecturer

Associate Chair for Undergraduate Studies

Ph.D., Fordham University

Areas of Interest: Macroeconomics, Money and Banking

Rose Hill, Dealy E-508[[email protected]](/cdn-cgi/l/email-protection#0f626d7a7d646a4f69607d6b676e62216a6b7a)

718-817-4048/4056Michael Calamari


Lecturer

Ph.D., Fordham University

Areas of Interest:

Rose Hill, Dealy E-515[[email protected]](/cdn-cgi/l/email-protection#cca1aeb9bea7a98caaa3bea8a4ada1e2a9a8b9)Cesar Castope


Lecturer

MA Pace University

Areas of Interest: Macroeconomics, Money and Banking

Rose Hill, Dealy E-509[[email protected]](/cdn-cgi/l/email-protection#bed3dccbccd5dbfed8d1ccdad6dfd390dbdacb)[Sean M. Collins](/academics/departments/economics/faculty/sean-m-collins/)

Professor of Economics

Associate Chair for Undergraduate Studies

Ph.D., Florida State University

Areas of Interest: Microeconomics, Financial Economics, Experimental Economics

Rose Hill, Dealy E-528[[email protected]](/cdn-cgi/l/email-protection#b3c0d0dcdfdfdaddc08286f3d5dcc1d7dbd2de9dd6d7c6)

718-817-0063[Mary Beth Combs](/academics/departments/economics/faculty/mary-beth-combs/)

Associate Professor of Economics

Ph.D., University of Iowa

Areas of Interest: Economic History, Labor Economics, Applied Microeconomics

Rose Hill, Dealy E-523[[email protected]](/cdn-cgi/l/email-protection#d0bdb3bfbdb2a390b6bfa2b4b8b1bdfeb5b4a5)

718-817-3542[Marc N. Conte](/academics/departments/economics/faculty/marc-n-conte/)

Professor of Economics

Ph.D., University of California, Santa Barbara

Areas of Interest: Environmental Economics, Applied Microeconomics, Public Finance

Rose Hill, Dealy E-521[[email protected]](/cdn-cgi/l/email-protection#ea878985849e8fddaa8c85988e828b87c48f8e9f)

718-817-3870[Utteeyo Dasgupta](/academics/departments/economics/faculty/utteeyo-dasgupta/)

Professor of Economics

Ph.D., University of Arizona

Areas of Interest: Experimental Economics, Behavioral Economics, Game Theory, Applied Microeconomics

Rose Hill, Dealy E-512[[email protected]](/cdn-cgi/l/email-protection#7f0a1b1e0c180a0f0b1e4e3f19100d1b171e12511a1b0a)

718-817-4062[Federico Esposito](/academics/departments/economics/faculty/federico-esposito/)

Assistant Professor of Economics

Ph.D., Yale University

Areas of Interest: International Trade, International Finance, Spatial Economics

Rose Hill, Dealy E-526[[email protected]](/cdn-cgi/l/email-protection#2b4d4e585b4458425f441f6b4d44594f434a46054e4f5e)

718-817-4065[Johanna L. Francis](/academics/departments/economics/faculty/johanna-l-francis/)

Associate Professor of Economics

Department Chair

Director of Graduate Studies

Ph.D., Johns Hopkins University

Areas of Interest: Macroeconomics, Open Economy Macroeconomics

Rose Hill, Dealy E-507[[email protected]](/cdn-cgi/l/email-protection#97f6fdf8f1e5f6f9f4fee4d7f1f8e5f3fff6fab9f2f3e2)

718-817-4048/4055Ilhami Gunduz


Lecturer

Ph.D., The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#85ece2f0ebe1f0ffc5e3eaf7e1ede4e8abe0e1f0)

718-817-4048[Ralf Hepp](/academics/departments/economics/faculty/ralf-hepp/)*(on research leave in academic year 2025/26)*

Associate Professor of Economics

Ph.D., University of California, Santa Cruz

Areas of Interest: Open Economy Macroeconomics, International Finance, International Trade, Monetary Economics, Banking and Finance

Rose Hill, Dealy E-525[[email protected]](/cdn-cgi/l/email-protection#d2bab7a2a292b4bda0b6bab3bffcb7b6a7)

718-817-4066Mohammad Ismail


Lecturer

PhD, Southern New Hampshire University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#731e1a001e121a1f424533151c01171b121e5d161706)

718-817-4048[Jhilam Z. Iqbal](/academics/departments/economics/faculty/jhilam-z-iqbal/)

Senior Lecturer

Ph.D., Fordham University

Areas of Interest: Economic Development, Micro-finance, International Trade

Lincoln Center, Lowenstein 915A[[email protected]](/cdn-cgi/l/email-protection#d4bda5b6b5b894b2bba6b0bcb5b9fab1b0a1)

212-636-638[Duncan James](/academics/departments/economics/faculty/duncan-james/)

Professor of Economics

Ph.D., University of Arizona

Areas of Interest: Applied Microeconomics, Finance, Experimental Economics

Lincoln Center, Lowenstein 924G[[email protected]](https://www.fordham.edu/info/20936/dujames@fordham.edu)

212-636-7080[Jerome Lahaye](/academics/departments/economics/faculty/jerome-lahaye/)

Associate Professor of Economics

Ph.D., University of Louvain-la-Neuve and Namur (Belgium)

Areas of Interest: Applied Econometrics, Time Series, International Economics and Finance

Lincoln Center, Lowenstein 916D[[email protected]](https://www.fordham.edu/info/20936/jlahaye@fordham.edu)

212-636-6343[Subha Mani](/academics/departments/economics/faculty/subha-mani/)

Professor of Economics

Ph.D., University of Southern California

Areas of Interest: Development Economics, Applied Microeconomics, and Applied Econometrics

Rose Hill, Dealy E-520[[email protected]](https://www.fordham.edu/info/20936/smani@fordham.edu)

718-817-3636[Sophie Mitra](/academics/departments/economics/faculty/sophie-mitra/)

Professor of Economics

Founding director of the[Research Consortium on Disability](/academics/research/faculty-research/research-consortium-on-disability/)[CSWEP](https://www.aeaweb.org/about-aea/committees/cswep)representative

Ph.D., Universite Paris I Pantheon-Sorbonne (France) Areas of Interest: Applied Microeconomics, Development, Disability and Health

Rose Hill, Dealy E-524[[email protected]](https://www.fordham.edu/info/20936/mitra@fordham.edu)

718-817-5337[Bartholomew J. Moore](/academics/departments/economics/faculty/bartholomew-j-moore/)

Associate Professor of Economics

Ph.D., Columbia University

Areas of Interest: Macroeconomic Theory, Monetary Theory, and Policy, Analysis and Modelling of Expectations

Rose Hill, Dealy E-511[[email protected]](https://www.fordham.edu/info/20936/bmoore@fordham.edu)

718-817-4049[Erick W. Rengifo](/academics/departments/economics/faculty/erick-w-rengifo/)

Professor of Economics

Director,[Center for International Policy Studies (CIPS)](https://www.fordham.edu/info/24283/center_for_international_policy_studies)

Ph.D., Universite Catholique de Louvain (Belgium)

Areas of Interest: Financial Economics, Microfinance, and Econometrics

Rose Hill, Dealy E-513[[email protected]](https://www.fordham.edu/info/20936/rengifomina@fordham.edu)

718-817-4061[David Rosenkranz](/academics/departments/economics/faculty/david-a-rosenkranz/#d.en.142974)

Assistant Professor of Economics

Ph.D., Columbia University

Areas of Interest: Applied microeconomics, health economics, industrial organization

Rose Hill, Dealy Hall E-510[[email protected]](/cdn-cgi/l/email-protection#4125332e32242f2a33202f3b01272e332529202c6f242534)

718-817-4058[Giacomo Santangelo](/academics/departments/economics/faculty/giacomo-santangelo/)

Senior Lecturer

Advisor for[International Policy Economy (IPE)](/academics/departments/international-political-economy-and-development/undergraduate-program-for-international-political-economy/#d.en.17727)Majors

Ph.D., Fordham University

Areas of Interest: Macroeconomics, International Economics

Rose Hill, Dealy E-515[[email protected]](https://www.fordham.edu/info/20936/salvatore@fordham.edu)

718-817-3844[Pablo Schenone](/academics/departments/economics/faculty/pablo-schenone/)*(on research leave in academic year 2025/26)*

Associate Professor of Economics

Ph.D., Northwestern University

Areas of Interest: Decision Theory, Game Theory, Network Theory

Rose Hill, Dealy E-509[[email protected]](https://www.fordham.edu/info/20936/pschenone@fordham.edu)

718-817-4057[Henry Schwalbenberg](/academics/departments/economics/faculty/henry-schwalbenberg/)

Associate Professor of Economics

Director,[International Political Economy and Development (IPED)](https://www.fordham.edu/iped)

Ph.D., Columbia University

Areas of Interest: International Economic Policy, Development

Rose Hill, Dealy E-519[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-4059[Philip Shaw](/academics/departments/economics/faculty/philip-shaw/)

Associate Professor of Economics

Advisor for[Mathematics-Economics](/academics/departments/mathematics-economics/#d.en.17152)Majors

Ph.D., University of Connecticut

Areas of Interest: Macroeconomics, Economic Growth, Computational Economics, Econometrics

Rose Hill, Dealy E-522[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-3564[Andrew Simons](/academics/departments/economics/faculty/andrew-simons/)

Associate Professor of Economics

Ph.D., Cornell University

Areas of Interest: Economic Development, Social Innovation, and Environmental Economics

Rose Hill, Dealy Hall E-506[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-4054[Troy L. Tassier](/academics/departments/economics/faculty/troy-l-tassier/)

Professor of Economics

Ph.D., University of Iowa

Areas of Interest: Microeconomics, Social Network Theory

Rose Hill, Dealy E-527[[email protected]](https://www.fordham.edu/info/20936/tassier@fordham.edu)

718-817-4793[Booi Themeli](/academics/departments/economics/faculty/booi-themeli/)

Senior Lecturer

Ph.D., Fordham University

Areas of Interest: African Economic Development, Emerging Markets: South Africa, Project Assessment

Rose Hill, Dealy 117-I[[email protected]](https://www.fordham.edu/info/20936/themeli@fordham.edu)

718-817-4618[Shapoor Vali](/academics/departments/economics/faculty/shapoor-vali/)

Associate Professor of Economics

Ph.D., University of Pittsburgh

Areas of Interest: Regional Economics, Econometrics, Mathematical Economics

Lincoln Center, Lowenstein 921E[[email protected]](https://www.fordham.edu/info/20936/vali@fordham.edu)

212-636-6240Jookyung Yoo


Senior Lecturer

Pd.D., Ph.D., North Carolina State University

Rose Hill, Dealy E-534[[email protected]](/cdn-cgi/l/email-protection#214b52544f461361474e534549404c0f444554)

718-817-3773[Jiangang Zeng](https://sites.google.com/view/jiangangzeng)

Assistant Professor of Economics

Ph.D., University of Texas - Austin

Areas of Interest: Micro-Econometrics

Rose Hill, Dealy E-505[[email protected]](/cdn-cgi/l/email-protection#e78d9d828980d2dea7818895838f868ac9828392)

718-817-4053 -
Kole Camaj


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#a7ccc4c6cac6cd94e7c1c8d5c3cfc6ca89c2c3d2)

718-817-4048Robert Derrell


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#6703021515020b0b27010815030f060a49020312)

718-817-4048Anitarose Dziwura


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#c5a4a1bfacb2b0b7a485a3aab7a1ada4a8eba0a1b0)

718-817-4048Carlos Elias


Adjunct Professor

PhD, New York University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#87e4e2ebeee6f4b6c7e1e8f5e3efe6eaa9e2e3f2)

718-817-4048Marjan Fadavi Ardekani


Adjunct Professor

PhD, The New School

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#503d363134312639312234353b313e3910363f223438313d7e353425)

718-817-4048William Foote


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#176071787863722657717865737f767a39727362)

718-817-4048Rukhama Halim


Adjunct Professor

MA, City College (CUNY)

Rose Hill, Dealy E-542[[email protected]](/cdn-cgi/l/email-protection#86f4eee7eaefebc6e0e9f4e2eee7eba8e3e2f3)

718-817-4048Tzu Hao Huang


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#91e5f9e4f0fff6a2a8d1f7fee3f5f9f0fcbff4f5e4)

718-817-4048Georgios Koimisis


Adjunct Professor

PhD, City University of New York

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#0c6b67636561657f657f4c6a637e68646d6122696879)

718-817-4048Boyao "Peter" Li


Adjunct Professor

PhD, New York University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#482a2421797a7a082e273a2c202925662d2c3d)

718-817-4048Yuhao Li


Adjunct Professor

Ph.D. Candidate, The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#334a5f5a0a010b73555c41575b525e1d565746)

718-817-4048Anthony Mannara


Adjunct Professor

Rose Hill, Dealy Hall / Lincoln Center, LL 924D[[email protected]](/cdn-cgi/l/email-protection#c3a2aea2adada2b1a2f283a5acb1a7aba2aeeda6a7b6)

718-817-4048Omar Robles


Adjunct Professor

PhD, Harvard University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#a1ced3cec3cdc4d292e1c7ced3c5c9c0cc8fc4c5d4)

718-817-4048Sadia Salman


Adjunct Professor

Lincoln Center, LL 9th Floor[[email protected]](/cdn-cgi/l/email-protection#433030222f222e7703252c31272b222e6d262736)

718-817-4048Antonio Sanchez


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#81e0f2e0efe2e9e4fbb0b5b4c1e7eef3e5e9e0ecafe4e5f4)

718-817-4048Mark Sheppard


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#7b1608131e0b0b1a091f4d3b1d14091f131a16551e1f0e)

718-817-4048Anthony Shiwmangal


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#6607150e0f110b070801070a26000914020e070b48030213)

718-817-4048Patrick Wall


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#becec9dfd2d28ffed8d1ccdad6dfd390dbdacb)

718-817-4048Yang Xiao


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#ee9796878f81dfdfddae88819c8a868f83c08b8a9b)

718-817-4048Sang Won Yoon


Adjunct Professor

Ph.D., University of Maryland, College Park

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#b7c4ced8d8d9838ff7d1d8c5d3dfd6da99d2d3c2)

718-817-4048Zhenye Zhong


Adjunct Professor

Ph.D. Candidate, The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#b0cacad8dfded78384f0d6dfc2d4d8d1dd9ed5d4c5)

718-817-4048 -
Janis Barry


Associate Professor of Economics

Ph.D., The New School

Areas of Interest: Labor Economics, Health Economics, Industrial Organization[[email protected]](/cdn-cgi/l/email-protection#35775447474c735c524050475a75535a47515d54581b505140)[Robert J. Brent](/academics/departments/economics/faculty/robert-j-brent/)

Professor Emeritus of Economics

Ph.D., University of Manchester (U.K.)

Areas of Interest: Cost-Benefit-Analysis, Health Economics[[email protected]](/cdn-cgi/l/email-protection#f39181969d87b3959c81979b929edd969786)Michael Buckley


Senior Lecturer[Frederick Campano](/academics/departments/economics/faculty/frederick-campano/)

Lecturer

M.S., Stanford University

Areas of Interest: Economic Forecasting, Development[[email protected]](/cdn-cgi/l/email-protection#1a7c797b776a7b74755a7c75687e727b77347f7e6f)Edward Dowling, SJ


Professor Emeritus of Economics

Mathematical EconomicsDarryl McLeod


Associate Professor of Economics

Ph.D., University of California, Berkeley

Areas of Interest: Development Economics[[email protected]](/cdn-cgi/l/email-protection#7c111f101913183c1a130e18141d1152191809)[Dominick Salvatore](/academics/departments/economics/faculty/dominick-salvatore/)

Distinguished Professor Emeritus of Economics

Ph.D., City University of New York (CUNY Graduate Center)

Areas of Interest: Microeconomics, International Economics[[email protected]](/cdn-cgi/l/email-protection#abd8cac7ddcadfc4d9ceebcdc4d9cfc3cac685cecfde)[Hrishikesh D. Vinod](/academics/departments/economics/faculty/hrishikesh-d-vinod/)

Professor Emeritus of Economics

Director,[Institute for Ethics and Economic Policy (IEEP)](https://www.fordham.edu/economics/vinod)

Ph.D., Harvard University

Areas of Interest: Econometrics[[email protected]](/cdn-cgi/l/email-protection#2056494e4f4460464f524448414d0e454455)Greg Winczewski


Ph.D., Fordham University

Areas of Interest: International Economics, International Political Economy[[email protected]](https://www.fordham.edu/info/20936/winczewski@fordham.edu)**In Memoriam**[Joseph Cammarosano](https://news.fordham.edu/university-news/university-mourns-loss-of-joseph-cammarosano-the-beating-heart-of-fordham/)

Professor Emeritus