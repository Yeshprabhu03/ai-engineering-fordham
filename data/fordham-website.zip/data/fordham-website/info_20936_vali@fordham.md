https://www.fordham.edu/info/20936/vali@fordham.edu

# Faculty

-
Alan Anderson


Lecturer

Ph.D., Fordham University

Rose Hill, Dealy E-543[[email protected]](/cdn-cgi/l/email-protection#6504040b010017160a0b5325030a17010d04084b000110)

718-817-4048[Mary Burke](/academics/departments/economics/faculty/mary-burke/)

Senior Lecturer

Associate Chair for Undergraduate Studies

Ph.D., Fordham University

Areas of Interest: Macroeconomics, Money and Banking

Rose Hill, Dealy E-508[[email protected]](/cdn-cgi/l/email-protection#610c0314130a0421070e130509000c4f040514)

718-817-4048/4056Michael Calamari


Lecturer

Ph.D., Fordham University

Areas of Interest:

Rose Hill, Dealy E-515[[email protected]](/cdn-cgi/l/email-protection#b7dad5c2c5dcd2f7d1d8c5d3dfd6da99d2d3c2)Cesar Castope


Lecturer

MA Pace University

Areas of Interest: Macroeconomics, Money and Banking

Rose Hill, Dealy E-509[[email protected]](/cdn-cgi/l/email-protection#d1bcb3a4a3bab491b7bea3b5b9b0bcffb4b5a4)[Sean M. Collins](/academics/departments/economics/faculty/sean-m-collins/)

Professor of Economics

Associate Chair for Undergraduate Studies

Ph.D., Florida State University

Areas of Interest: Microeconomics, Financial Economics, Experimental Economics

Rose Hill, Dealy E-528[[email protected]](/cdn-cgi/l/email-protection#bac9d9d5d6d6d3d4c98b8ffadcd5c8ded2dbd794dfdecf)

718-817-0063[Mary Beth Combs](/academics/departments/economics/faculty/mary-beth-combs/)

Associate Professor of Economics

Ph.D., University of Iowa

Areas of Interest: Economic History, Labor Economics, Applied Microeconomics

Rose Hill, Dealy E-523[[email protected]](/cdn-cgi/l/email-protection#48252b27252a3b082e273a2c202925662d2c3d)

718-817-3542[Marc N. Conte](/academics/departments/economics/faculty/marc-n-conte/)

Professor of Economics

Ph.D., University of California, Santa Barbara

Areas of Interest: Environmental Economics, Applied Microeconomics, Public Finance

Rose Hill, Dealy E-521[[email protected]](/cdn-cgi/l/email-protection#fc919f93928899cbbc9a938e98949d91d2999889)

718-817-3870[Utteeyo Dasgupta](/academics/departments/economics/faculty/utteeyo-dasgupta/)

Professor of Economics

Ph.D., University of Arizona

Areas of Interest: Experimental Economics, Behavioral Economics, Game Theory, Applied Microeconomics

Rose Hill, Dealy E-512[[email protected]](/cdn-cgi/l/email-protection#d3a6b7b2a0b4a6a3a7b2e293b5bca1b7bbb2befdb6b7a6)

718-817-4062[Federico Esposito](/academics/departments/economics/faculty/federico-esposito/)

Assistant Professor of Economics

Ph.D., Yale University

Areas of Interest: International Trade, International Finance, Spatial Economics

Rose Hill, Dealy E-526[[email protected]](/cdn-cgi/l/email-protection#b9dfdccac9d6cad0cdd68df9dfd6cbddd1d8d497dcddcc)

718-817-4065[Johanna L. Francis](/academics/departments/economics/faculty/johanna-l-francis/)

Associate Professor of Economics

Department Chair

Director of Graduate Studies

Ph.D., Johns Hopkins University

Areas of Interest: Macroeconomics, Open Economy Macroeconomics

Rose Hill, Dealy E-507[[email protected]](/cdn-cgi/l/email-protection#e98883868f9b88878a809aa98f869b8d818884c78c8d9c)

718-817-4048/4055Ilhami Gunduz


Lecturer

Ph.D., The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#600907150e04151a20060f120408010d4e050415)

718-817-4048[Ralf Hepp](/academics/departments/economics/faculty/ralf-hepp/)*(on research leave in academic year 2025/26)*

Associate Professor of Economics

Ph.D., University of California, Santa Cruz

Areas of Interest: Open Economy Macroeconomics, International Finance, International Trade, Monetary Economics, Banking and Finance

Rose Hill, Dealy E-525[[email protected]](/cdn-cgi/l/email-protection#b0d8d5c0c0f0d6dfc2d4d8d1dd9ed5d4c5)

718-817-4066Mohammad Ismail


Lecturer

PhD, Southern New Hampshire University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#8de0e4fee0ece4e1bcbbcdebe2ffe9e5ece0a3e8e9f8)

718-817-4048[Jhilam Z. Iqbal](/academics/departments/economics/faculty/jhilam-z-iqbal/)

Senior Lecturer

Ph.D., Fordham University

Areas of Interest: Economic Development, Micro-finance, International Trade

Lincoln Center, Lowenstein 915A[[email protected]](/cdn-cgi/l/email-protection#563f2734373a16303924323e373b78333223)

212-636-638[Duncan James](/academics/departments/economics/faculty/duncan-james/)

Professor of Economics

Ph.D., University of Arizona

Areas of Interest: Applied Microeconomics, Finance, Experimental Economics

Lincoln Center, Lowenstein 924G[[email protected]](https://www.fordham.edu/info/20936/dujames@fordham.edu)

212-636-7080[Jerome Lahaye](/academics/departments/economics/faculty/jerome-lahaye/)

Associate Professor of Economics

Ph.D., University of Louvain-la-Neuve and Namur (Belgium)

Areas of Interest: Applied Econometrics, Time Series, International Economics and Finance

Lincoln Center, Lowenstein 916D[[email protected]](https://www.fordham.edu/info/20936/jlahaye@fordham.edu)

212-636-6343[Subha Mani](/academics/departments/economics/faculty/subha-mani/)

Professor of Economics

Ph.D., University of Southern California

Areas of Interest: Development Economics, Applied Microeconomics, and Applied Econometrics

Rose Hill, Dealy E-520[[email protected]](https://www.fordham.edu/info/20936/smani@fordham.edu)

718-817-3636[Sophie Mitra](/academics/departments/economics/faculty/sophie-mitra/)

Professor of Economics

Founding director of the[Research Consortium on Disability](/academics/research/faculty-research/research-consortium-on-disability/)[CSWEP](https://www.aeaweb.org/about-aea/committees/cswep)representative

Ph.D., Universite Paris I Pantheon-Sorbonne (France) Areas of Interest: Applied Microeconomics, Development, Disability and Health

Rose Hill, Dealy E-524[[email protected]](https://www.fordham.edu/info/20936/mitra@fordham.edu)

718-817-5337[Bartholomew J. Moore](/academics/departments/economics/faculty/bartholomew-j-moore/)

Associate Professor of Economics

Ph.D., Columbia University

Areas of Interest: Macroeconomic Theory, Monetary Theory, and Policy, Analysis and Modelling of Expectations

Rose Hill, Dealy E-511[[email protected]](https://www.fordham.edu/info/20936/bmoore@fordham.edu)

718-817-4049[Erick W. Rengifo](/academics/departments/economics/faculty/erick-w-rengifo/)

Professor of Economics

Director,[Center for International Policy Studies (CIPS)](https://www.fordham.edu/info/24283/center_for_international_policy_studies)

Ph.D., Universite Catholique de Louvain (Belgium)

Areas of Interest: Financial Economics, Microfinance, and Econometrics

Rose Hill, Dealy E-513[[email protected]](https://www.fordham.edu/info/20936/rengifomina@fordham.edu)

718-817-4061[David Rosenkranz](/academics/departments/economics/faculty/david-a-rosenkranz/#d.en.142974)

Assistant Professor of Economics

Ph.D., Columbia University

Areas of Interest: Applied microeconomics, health economics, industrial organization

Rose Hill, Dealy Hall E-510[[email protected]](/cdn-cgi/l/email-protection#b5d1c7dac6d0dbdec7d4dbcff5d3dac7d1ddd4d89bd0d1c0)

718-817-4058[Giacomo Santangelo](/academics/departments/economics/faculty/giacomo-santangelo/)

Senior Lecturer

Advisor for[International Policy Economy (IPE)](/academics/departments/international-political-economy-and-development/undergraduate-program-for-international-political-economy/#d.en.17727)Majors

Ph.D., Fordham University

Areas of Interest: Macroeconomics, International Economics

Rose Hill, Dealy E-515[[email protected]](https://www.fordham.edu/info/20936/salvatore@fordham.edu)

718-817-3844[Pablo Schenone](/academics/departments/economics/faculty/pablo-schenone/)*(on research leave in academic year 2025/26)*

Associate Professor of Economics

Ph.D., Northwestern University

Areas of Interest: Decision Theory, Game Theory, Network Theory

Rose Hill, Dealy E-509[[email protected]](https://www.fordham.edu/info/20936/pschenone@fordham.edu)

718-817-4057[Henry Schwalbenberg](/academics/departments/economics/faculty/henry-schwalbenberg/)

Associate Professor of Economics

Director,[International Political Economy and Development (IPED)](https://www.fordham.edu/iped)

Ph.D., Columbia University

Areas of Interest: International Economic Policy, Development

Rose Hill, Dealy E-519[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-4059[Philip Shaw](/academics/departments/economics/faculty/philip-shaw/)

Associate Professor of Economics

Advisor for[Mathematics-Economics](/academics/departments/mathematics-economics/#d.en.17152)Majors

Ph.D., University of Connecticut

Areas of Interest: Macroeconomics, Economic Growth, Computational Economics, Econometrics

Rose Hill, Dealy E-522[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-3564[Andrew Simons](/academics/departments/economics/faculty/andrew-simons/)

Associate Professor of Economics

Ph.D., Cornell University

Areas of Interest: Economic Development, Social Innovation, and Environmental Economics

Rose Hill, Dealy Hall E-506[[email protected]](https://www.fordham.edu/info/20936/schwalbenber@fordham.edu)

718-817-4054[Troy L. Tassier](/academics/departments/economics/faculty/troy-l-tassier/)

Professor of Economics

Ph.D., University of Iowa

Areas of Interest: Microeconomics, Social Network Theory

Rose Hill, Dealy E-527[[email protected]](https://www.fordham.edu/info/20936/tassier@fordham.edu)

718-817-4793[Booi Themeli](/academics/departments/economics/faculty/booi-themeli/)

Senior Lecturer

Ph.D., Fordham University

Areas of Interest: African Economic Development, Emerging Markets: South Africa, Project Assessment

Rose Hill, Dealy 117-I[[email protected]](https://www.fordham.edu/info/20936/themeli@fordham.edu)

718-817-4618[Shapoor Vali](/academics/departments/economics/faculty/shapoor-vali/)

Associate Professor of Economics

Ph.D., University of Pittsburgh

Areas of Interest: Regional Economics, Econometrics, Mathematical Economics

Lincoln Center, Lowenstein 921E[[email protected]](https://www.fordham.edu/info/20936/vali@fordham.edu)

212-636-6240Jookyung Yoo


Senior Lecturer

Pd.D., Ph.D., North Carolina State University

Rose Hill, Dealy E-534[[email protected]](/cdn-cgi/l/email-protection#d2b8a1a7bcb5e092b4bda0b6bab3bffcb7b6a7)

718-817-3773[Jiangang Zeng](https://sites.google.com/view/jiangangzeng)

Assistant Professor of Economics

Ph.D., University of Texas - Austin

Areas of Interest: Micro-Econometrics

Rose Hill, Dealy E-505[[email protected]](/cdn-cgi/l/email-protection#cba1b1aea5acfef28bada4b9afa3aaa6e5aeafbe)

718-817-4053 -
Kole Camaj


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#d5beb6b4b8b4bfe695b3baa7b1bdb4b8fbb0b1a0)

718-817-4048Robert Derrell


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#6602031414030a0a26000914020e070b48030213)

718-817-4048Anitarose Dziwura


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#1776736d7e6062657657717865737f767a39727362)

718-817-4048Carlos Elias


Adjunct Professor

PhD, New York University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#056660696c64763445636a77616d64682b606170)

718-817-4048Marjan Fadavi Ardekani


Adjunct Professor

PhD, The New School

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#95f8f3f4f1f4e3fcf4e7f1f0fef4fbfcd5f3fae7f1fdf4f8bbf0f1e0)

718-817-4048William Foote


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#c3b4a5acacb7a6f283a5acb1a7aba2aeeda6a7b6)

718-817-4048Rukhama Halim


Adjunct Professor

MA, City College (CUNY)

Rose Hill, Dealy E-542[[email protected]](/cdn-cgi/l/email-protection#9ceef4fdf0f5f1dcfaf3eef8f4fdf1b2f9f8e9)

718-817-4048Tzu Hao Huang


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#493d213c28272e7a70092f263b2d212824672c2d3c)

718-817-4048Georgios Koimisis


Adjunct Professor

PhD, City University of New York

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#25424e4a4c484c564c5665434a57414d44480b404150)

718-817-4048Boyao "Peter" Li


Adjunct Professor

PhD, New York University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#10727c7921222250767f627478717d3e757465)

718-817-4048Yuhao Li


Adjunct Professor

Ph.D. Candidate, The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#641d080d5d565c24020b16000c05094a010011)

718-817-4048Anthony Mannara


Adjunct Professor

Rose Hill, Dealy Hall / Lincoln Center, LL 924D[[email protected]](/cdn-cgi/l/email-protection#9bfaf6faf5f5fae9faaadbfdf4e9fff3faf6b5feffee)

718-817-4048Omar Robles


Adjunct Professor

PhD, Harvard University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#80eff2efe2ece5f3b3c0e6eff2e4e8e1edaee5e4f5)

718-817-4048Sadia Salman


Adjunct Professor

Lincoln Center, LL 9th Floor[[email protected]](/cdn-cgi/l/email-protection#dfacacbeb3beb2eb9fb9b0adbbb7beb2f1babbaa)

718-817-4048Antonio Sanchez


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#69081a08070a010c13585d5c290f061b0d010804470c0d1c)

718-817-4048Mark Sheppard


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#dcb1afb4b9acacbdaeb8ea9cbab3aeb8b4bdb1f2b9b8a9)

718-817-4048Anthony Shiwmangal


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#90f1e3f8f9e7fdf1fef7f1fcd0f6ffe2f4f8f1fdbef5f4e5)

718-817-4048Patrick Wall


Adjunct Professor

PhD, Fordham University

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#6c1c1b0d00005d2c0a031e08040d0142090819)

718-817-4048Yang Xiao


Adjunct Professor

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#334a4b5a525c02020073555c41575b525e1d565746)

718-817-4048Sang Won Yoon


Adjunct Professor

Ph.D., University of Maryland, College Park

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#bccfc5d3d3d28884fcdad3ced8d4ddd192d9d8c9)

718-817-4048Zhenye Zhong


Adjunct Professor

Ph.D. Candidate, The Graduate Center, CUNY

Rose Hill, Dealy Hall[[email protected]](/cdn-cgi/l/email-protection#e993938186878edadda98f869b8d818884c78c8d9c)

718-817-4048 -
Janis Barry


Associate Professor of Economics

Ph.D., The New School

Areas of Interest: Labor Economics, Health Economics, Industrial Organization[[email protected]](/cdn-cgi/l/email-protection#baf8dbc8c8c3fcd3ddcfdfc8d5fadcd5c8ded2dbd794dfdecf)[Robert J. Brent](/academics/departments/economics/faculty/robert-j-brent/)

Professor Emeritus of Economics

Ph.D., University of Manchester (U.K.)

Areas of Interest: Cost-Benefit-Analysis, Health Economics[[email protected]](/cdn-cgi/l/email-protection#553727303b2115333a27313d34387b303120)Michael Buckley


Senior Lecturer[Frederick Campano](/academics/departments/economics/faculty/frederick-campano/)

Lecturer

M.S., Stanford University

Areas of Interest: Economic Forecasting, Development[[email protected]](/cdn-cgi/l/email-protection#214742404c51404f4e61474e534549404c0f444554)Edward Dowling, SJ


Professor Emeritus of Economics

Mathematical EconomicsDarryl McLeod


Associate Professor of Economics

Ph.D., University of California, Berkeley

Areas of Interest: Development Economics[[email protected]](/cdn-cgi/l/email-protection#6a0709060f050e2a0c05180e020b07440f0e1f)[Dominick Salvatore](/academics/departments/economics/faculty/dominick-salvatore/)

Distinguished Professor Emeritus of Economics

Ph.D., City University of New York (CUNY Graduate Center)

Areas of Interest: Microeconomics, International Economics[[email protected]](/cdn-cgi/l/email-protection#7102101d0710051e031431171e031519101c5f141504)[Hrishikesh D. Vinod](/academics/departments/economics/faculty/hrishikesh-d-vinod/)

Professor Emeritus of Economics

Director,[Institute for Ethics and Economic Policy (IEEP)](https://www.fordham.edu/economics/vinod)

Ph.D., Harvard University

Areas of Interest: Econometrics[[email protected]](/cdn-cgi/l/email-protection#3147585f5e5571575e435559505c1f545544)Greg Winczewski


Ph.D., Fordham University

Areas of Interest: International Economics, International Political Economy[[email protected]](https://www.fordham.edu/info/20936/winczewski@fordham.edu)**In Memoriam**[Joseph Cammarosano](https://news.fordham.edu/university-news/university-mourns-loss-of-joseph-cammarosano-the-beating-heart-of-fordham/)

Professor Emeritus