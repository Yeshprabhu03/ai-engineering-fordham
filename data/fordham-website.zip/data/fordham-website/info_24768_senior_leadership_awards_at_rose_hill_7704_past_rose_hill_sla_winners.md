https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners

# Past Rose Hill SLA Winners

## Award Winners by Year

**1980s:** [1981](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1981) | [1982](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1982) | [1983](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1983) | [1984](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1984) | [1985](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1985) | [1986](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1986) | [1989](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1989)**1990s:** [1990](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1990) | [1991](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1991) | [1992](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1992) | [1993](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1993) | [1994](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1994) | [1995](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1995) | [1996](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1996) | [1997](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1997) | [1998](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1998) | [1999](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#1999)**2000s:** [2000](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2000) | [2001](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2001) | [2002](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2002) | [2003](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2003) | [2004](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2004) | [2005](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2005) | [2006](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2006) | [2007](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2007) | [2008](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2008) | [2009](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2009)**2010s:** [2010](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2010) | [2011](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2011) | [2012](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2012) | [2013](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2013) | [2014](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2014) | [2015](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2015) | [2016](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2016) | [2017](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2017) | [2018](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2018) | [2019](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2019)

**2020s:**

[2020](https://www.fordham.edu/info/24768/senior_leadership_awards_at_rose_hill/7704/past_rose_hill_sla_winners#2020)|

[2021](#2021)|

[2022](#2022)|

[2023](#2023)

### 1981

*College Leadership Award*

Robert Hahn

Robin J. Iverson

William Nocera

Stephen V. Rossettie

Marie Tassini

### 1982

*College Leadership Award*

Jeanmarie Brescia

Charles D. Brown

Christopher Falco

### 1983

*College Leadership Award*

Margaret Breen

Carol Kozeracki

Michael Martino

### 1984

*College Leadership Award*

Joseph Cerra

Mary Galligan

Margaret Hughes

Donald Langenhauer

### 1985

*College Leadership Award*

Julia Hall

John Antretter

Jeanne Killcommons

### 1986

*College Leadership Award*

Annemarie Wojcik

Pasquale Strocchia

Anne Calligan

Jennie D'Arrigo

### 1989

*College Leadership Award*

Raymond H. Brescia

Diana Comez

Mary B. O'Neil

Mary C. Plansky

William B. White

### 1990

*College Leadership Award*

Karen Caldaroni

Anthony Kaperick

Deirdre Dolan

Timothy Murray

Robert (Chris) Kuser

Michelle McLaughlin

### 1991

*College Leadership Award*

Laura Bombay

Peter Krokondelas

Brenda Murphy

Maryanne Tierney

### 1992

*Senior Leadership Award*

Robert Galle

Stephen Fahy

Brett Loney

Marc Schuhl

Bridget Boetig

Helen Sivulka

### 1993

*Senior Leadership Award*

Chris L. Davies

Munesh B. Jagnandan

Jerold R. Kulik

David E. Reidinger

### 1994

*Senior Leadership Award*

Christopher P. Bowers

Jennifer B. Cavanaugh

John P. Harvey

Brian R. Huss

Tara L. O'Brien

Frank P. Rizzo

### 1995

*Senior Leadership Award*

Jennifer S. Stein

Edward S. Gallagher

Lucrezia A. Civitano

Courtney J. Murphy

Gualberto J. Rodriguez

Russell B. Ashton

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Margaret A. Hobson

### 1996

*Senior Leadership Award*

Catherine A. Sabatos

Alfredo Gonzalez Jr.

Vincent T. Lavecchia

Daniel C. Maguire

Catherine M. Quinn

Megan L. O'Hare

Kristen E. Siddell

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

James P. Redmond

### 1997

*Senior Leadership Award*

Angelita Gomez

Raquel Granda

Sandra Lobo

George Musson

David Thomer

Michael Kiernan

Jennifer Mussi

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Eric J. Montroy

### 1998

*Senior Leadership Award*

James Gatta

Jose Morales

Anne Morrison

Andrea Porrovecchio

James Richichi

John Thorpe

Brian Whelan

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Kieran Farrell

### 1999

Senior Leadership Award

Richard Bond

Carrie Carrino

Megan Doyle

Kimberly Jacobellis

Bryan Lyman

Yamilette Osuna

Janeen Scaturro

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Simon Raffel

### 2000

*Senior Leadership Award*

Mary Kate Blaine

Veena Kapadia

Jennifer Marrotta

Sean Misciagna

Michael Puma

Brian Purnell

Cindy Vojtech

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Nick Napalitano

### 2001

*Senior Leadership Award*

Anthony Ferrante

Jennifer Hojaiban

Jonah Hulst

Charlie O'Donnell

Deanna Singh

Emily Spear

Edward Wahesh

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Marisa Martineau

### 2002

*Senior Leadership Award*

Paul Casey

Stacey Eger

Vivian Garcia-Tunon

Colleen Keller

Henry Solorzano

Patti Spinelli

Natalie Verette

Athena Zapantis

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Renaldo Alba

### 2003

*Senior Leadership Award*

Rachel Janairo

Beth Gallagher

Stephanie Irvin

Jin Lam

Leslie Mackrell

Gail Mulligan

Patrick Quinn

William Strauss

Kristin Tranetzki

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Steve Strong

### 2004

*Senior Leadership Award*

Jason Gutierrez

Braulio Carrero

Kimberly Easterling

Mary Owens

Darcy Walsh

Robert Hanley

Angela Paparone

Anne Pezzano

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Tiffany DiNome

### 2005

*Senior Leadership Award*

Keith McGilvery

Margaret DeMarco

Patrick Farmer

Elizabeth Amico

Jim DeProphetis

Berta Reid

Meghan O'Brien

Kristen Wares

Jeffrey Miragliotta

Andrea St. Pierre

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Eric Fergen

### 2006

*Senior Leadership Award*

Diane Adjetey

Sonny Mullen

Jonnah Caneda

Sarah Boyorak

Kim Daly

Candice Lee

Leah Moschella

Laura Lombardi

Tommie Stephens

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Heather Hargraves

### 2007

*Senior Leadership Award*

Alexander "Josh" Arcadia

Prescott Loveland

Zoila Mendez

Latasha Neil

Meghan Oster

Tyler Renaigel

Kathryn Rouillard

Alex Ticas

Ryan White

Meghan Wilcke

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Christine Perry

### 2008

*Senior Leadership Award*

Karen Brifu

Dan Cosacchi

Theresa Dean

Jenna Felz

Michael Partis

Jonathan Sousa

Marisa Villani

Jasmine Velazquez

Emily Wilant

Kristin Woodford

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Danielle Egic

### 2009

*Senior Leadership Award*

Michelle Costantino

Roxanne De La Torre

Danielle E. Gennaro

Matthew T. Niehaus

Cecilia B. Rodriguez

James J. Tickey

Brian M. Woodard

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Stephanie C. Crane

### 2010

*Senior Leadership Award*

Wander Cedeno

Elizabeth F. Donahue

Oludolapo A. Fakeye

John Tully Gordon

Sarika Mathur

Nicholas A. Passantino

Megan T. Shaughnessy

Michael R. Trerotola

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Carmela R. Dormani

### 2011

*Senior Leadership Award*

Jake Braithwaite

Ahmed Haruna

Jamal Haruna

Sara Kugel

Nora Moran

Adam Remiszewski

Jonathan Roque

Johanne Sterling

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Nova Lucero

### 2012

*Senior Leadership Award*

Matthew Cuff

Artie de los Santos

Elisa Dimauro

Angelo Labate

Brian Maits

Caitlin Meyer

Melissa Wright

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Hussein Safa

### 2013

*Senior Leadership Award*

Brandon Vazquez

Laura Buckley

Michael Sansarran

Juvoni Beckford

Stephen Erdman

Christopher Cepeda

Joanna Illardi

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Michael Martinez

### 2014

*Senior Leadership Award*

Ramon Cabral

Alex Chin Fong

Muhammad Sarwar

Sarah Hill

Anthony Gatti

Shannon McKenna

Antonio (Tony) Vozza

Brendan Francolini

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Stephen Ross

### 2015

*Senior Leadership Award*

Brandon Mogrovejo

Connie (CJ) Cacace

Emily Reynolds

Nevin Kulangara

Natalie Salerno

Alice Smyth

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Lauren Ross

### 2016

*Senior Leadership Award*

Timothy Bouffard

Nicholas Sawicki

Annelisa Tucker

Andrew Santis

Anisha Mirchandani

Nishant Sahoo

Christopher Hazlaris

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Scarly Rodriguez

### 2017

*Senior Leadership Award*

Cameron Rockelein

Emma Bausert

Stephen Esposito

Irene Kate Patron

Paola Joaquin Rosso

Salvatore Cocchiaro

Siobhan Donahue

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Vanessa Rotondo

*The Dorothy Day Peacemaker Award*

Chloe Potsklan

### 2018

*Senior Leadership Award*

Claire Siegrist

Amanda Vopat

Monica Olveira

Peter Vergara

Abigail Kedick

Nemesis Dipre

Martine De Matteo

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Siobhan Loughran

*The Dorothy Day Peacemaker Award*

Megan Townsend

### 2019

*Senior Leadership Award*

Vanessa Reyes

Ayesha Afridi

Charlotte Hakikson

Eric Stolar

Amanda D'Antone

Danielle Cammarasano

Kathryn Teaney

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Anya Patterson

*The Dorothy Day Peacemaker Award*

Neil Joyce

### 2020

*Senior Leadership Award*

Ashley Qamar

Emma Budd

Nathaniel Singh

Peyton Hayes

Kaylee Wong

Kaidya Adames

Jacklyn Onody

*The Rev. Joseph P. Fitzpatrick, S.J. Award*

Mia Beverly

*The Winton Medal for Distinguished Service to a Student Organization*

Aislin Keely, Editor in Chief of The Fordham Ram

*The Dorothy Day Peacemaker Award*

Alexa Valentin

### 2021

*Senior Leadership Award*

Dylan Garvey

Darren Tha

Jeffrey Pelayo

Reilly Keane

Samantha Barrett

Sandor Lorange

Shumaila Bibi

*The Rev. Joseph P. Fitzpatrick, S.J. Award*Diontay Santiago, President of Asili

*The Winton Medal for Distinguished Service to a Student Organization*

Olivia Quartell, Executive President of United Student Government

*The Dorothy Day Peacemaker Award*

Miranda Rydel

*Advisor of the Year*

John Carroll, Associate Vice President for Public Safety 1992-2022

### 2022

*Senior Leadership Award*

*The Rev. Joseph P. Fitzpatrick, S.J. Award*Ariana Chen

*The Winton Medal for Distinguished Service to a Student Organization*

Thomas Reuter, Executive President of United Student Government

*The Dorothy Day Peacemaker Award*

Mari Teli

### 2023

** The Dorothy Day Peacemaker Award**Amalia Sordo Palacios

** Reverend Joseph P. Fitzpatrick, S.J. Award: **Benedict J. Reilly

** Senior Leadership Awards**Maya Dominguez

Alessandra Carino

Alvin Feliz Varona

Chiara Holton

Rumaisa Khan

Juan Rodriguez

Catherine Bagin

** The Gambale Medal**Anna R. Sherman

* The Winton Medal*Ava DeVita