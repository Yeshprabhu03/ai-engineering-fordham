https://www.fordham.edu/information-technology/it-services/ram-print/release-print

# Release Print

### Overview

After submitting a print job to FineMe, web to print, or email to print, you can release the print job at any supported printer

### To release the print job

- Go to a Canon MFD machine
- Log in with your ID card, Fordham username and password, or QR code.
- Touch
**Release Print** - Select the document(s) to be printed
- Touch
**Print**to print your selected documents - If prompted, select which account you would like to charge
- Your account is charged only after the print request is complete

- When you are done, click the logout button.