https://www.fordham.edu/resources/coronavirus-updates/fordham-forward/fordham-forward-faqs

# Fordham Forward FAQs

**As of May 15, 2023, Fordham will no longer require members of the University community or visitors to be vaccinated against COVID-19.** Vaccinations and boosters will continue to be strongly recommended because they remain very effective in protecting each of us individually from serious illness and death.