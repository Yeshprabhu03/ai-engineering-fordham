https://www.fordham.edu/resources/policies/academic-integrity-policy/the-right-to-grieve-grades-in-relationship-to-violations-of-academic-integrity

# The Right to Grieve Grades in Relationship to Violations of Academic Integrity

Any other grades given for work in the same course, unless the grade itself is the sanction, can be grieved in accordance with the established college policy only after any and all questions of violations of academic integrity have been resolved through the processes stated above.

View the [Academic Integrity Violation Report ](/media/home/departments-centers-and-offices/policies/pdfs/Academic_Integrity_Violation_Report.pdf).