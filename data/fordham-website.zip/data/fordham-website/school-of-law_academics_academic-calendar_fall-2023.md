https://www.fordham.edu/school-of-law/academics/academic-calendar/fall-2023

Skip to Main Content
School of Law
Calendars
Law Library
Alumni
News
Give
About
Login to LawNET
School of Law
Search icon
Close Menu
Admissions
Arrow left icon
Back
J.D. Program
Apply
Tours and Info Sessions
After You've Applied
Admitted J.D. Students
Financial Aid
LL.M. Program
Apply
Areas and Specializations
Online LL.M. Programs
Admitted LL.M. Students
Financial Aid
M.S.L. Program
Apply
M.S.L. in Compliance
M.S.L in Fashion Law
Admitted M.S.L. Students
Financial Aid
S.J.D. Program
Apply
Colloquium
Current S.J.D. Students
Admitted S.J.D. Students
Financial Aid
Academics
Arrow left icon
Back
Curriculum
J.D. Program
LL.M. Program
M.S.L. Program
S.J.D. Program
Legal Writing Program
Experiential Education
Clinics
Externships
Pro Bono Scholars Program
Lawyering Skills
Centers & Institutes
Brendan Moore Trial Advocacy
Judicial Events & Clerkships
Asian Americans and the Law
European Union Law
Race, Law and Justice
Law Institute
Conflict Resolution and ADR Program
Corporate Law Center
Fashion Law Institute
Feerick Center for Social Justice
Fordham CLIP
Institute on Religion, Law and Lawyer's Work
Intellectual Property Institute
Leitner Center for International Law and Justice
National Center for Access to Justice
Neuroscience and Law Center
Public Interest Resource Center
Stein Center for Law and Ethics
Urban Law Center
Voting Rights and Democracy Project
Executive Education
Continuing Legal Education
Executive Programs
Law Firm Management
Executive Academic Programs
International Programs
International Student Programs
Summer Institute
Legal English Institute
J.D. Study Abroad
Semester Study Abroad Programs
Summer Study Abroad
Student Journals
Law Review
Urban Law Journal
International Law Journal
IP, Media & Entertainment Law
Environmental Law Review
Corporate and Financial Law
Registrar's Office
Academic Regulations
Bar Information
Examination Schedule
Graduation
Registration Information
Faculty
Arrow left icon
Back
Faculty Directory
Faculty by Expertise
Full-time Faculty
Adjunct Faculty
Emeriti Faculty
Visiting Faculty
Legal Writing Faculty
In Memoriam Faculty
Scholarship
Centers and Institutes
Scholarship Highlights
Faculty Books
FLASH Scholarship Archive
Faculty Podcasts
In Memoriam
Careers
Arrow left icon
Back
J.D. Career Support
Career Planning Center
Employment Statistics
LL.M./M.S.L./ S.J.D. Career Support
Graduate Professional Development Program
Employers
Post a Job
Recruiting J.D. Students
Recruiting LL.M. Students
Student Outreach Opportunities
Life at Fordham Law
Arrow left icon
Back
Studying Law in New York City
The Neighborhood
Build Your Career
Experiential Education
Visiting the Campus
Student Life
Student Affairs Office
Student Bar Association
Student Competitions
Student Organizations
Student Wellness
Professionalism Office
Public Interest and Service
Public Interest Curriculum
Public Interest Resource Center
A2J Initiative
Stein Scholars Program
Diversity Initiatives
IDEAL Pipeline Program
REAL Scholars Program
Diversity Faculty Directory
Student Diversity Organizations
Calendars
Law Library
Alumni
News
Give
About
Login to LawNET
Search icon
Menu icon
Search the site
Search icon
Close icon
Home
Academics
Colleges and Schools
Graduate Schools
School of Law
Academics
Academic Calendar
Fall 2023
School of Law Academic Calendar Fall 2023
2023-2024
Summer 2024
|
Fall 2024
|
Spring 2025
Fall 2023