https://www.fordham.edu/school-of-law/academics/international-programs/international-student-programs/legal-english-institute/schedule

# Legal English Fall 2025 Schedule

## Schedule

All sessions meet in room 2-01A unless otherwise noted.

This schedule is tentative, and a final schedule will be provided to participants on the first day of the program.

-
Date Description Time Wednesday, August 20 Welcome and Program Orientation 11:30 a.m. – 12:30 p.m. Welcome Lunch 12:30 – 1:30 p.m.

Location TBAIntroduction to the U.S. Legal System and Law Study 1:45 – 3:15 p.m. Welcome from Deans and Administration, followed by Reception (optional) 5:00 – 7:00 p.m. Thursday, August 21 Introduction to the U.S. Legal System and Law Study 9:30 a.m. – 12:30 p.m. Friday, August 22 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 12:30 p.m. -
Date Description Time Monday, August 25 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 1:00 p.m. Tuesday, August 26 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 1:00 p.m. Wednesday, August 27 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 1:00 p.m. Thursday, August 28 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, August 29 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. -
Date Description Time Monday, September 1 Law School Closed – Labor Day Tuesday, September 2 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, September 3 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 1:00 p.m. Thursday, September 4 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, September 5 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. -
Date Description Time Monday, September 8 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, September 9 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, September 10 Introduction to the U.S. Legal System and Law Study 9:00 a.m. – 1:00 p.m. Thursday, September 11 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, September 12 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, September 15 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, September 16 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, September 17 Introduction to the U.S. Legal System & Law Study 9:00 a.m. – 1:00 p.m. Thursday, September 18 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, September 19 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, September 22 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, September 23 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, September 24 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m.

Room 4-01Thursday, September 25 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, September 26 Exam Info Session with IT and the Registrar (bring your laptops) 9:00 a.m. – 10:15 a.m. -
Date Description Time Monday, September 29 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, September 30 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, October 1 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, October 2 Introduction to the U.S. Legal System and Law Study Exam 9:00 a.m. – 12:30 p.m. Friday, October 3 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, October 6 TBA 9:00 a.m. – 12:30 p.m. Tuesday, October 7 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, October 8 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, October 9 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, October 10 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, October 13 Law School Closed – Columbus Day Tuesday, October 14 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, October 15 TBA 9:00 a.m. – 12:30 p.m. Thursday, October 16 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, October 17 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, October 20 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, October 21 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, October 22 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, October 23 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, October 24 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, October 27 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Legal Professional Persona 1:00 – 5:30 p.m.

Room 1-01Tuesday, October 28 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Legal Professional Persona 1:00 – 5:30 p.m.

Room 1-01Wednesday, October 29 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, October 30 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Legal Professional Persona 1:00 – 5:30 p.m.

Room 1-01Friday, October 31 Legal English Tutorial 9:00 a.m. – 12:30 p.m. -
Date Description Time Monday, November 3 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Tuesday, November 4 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, November 5 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, November 6 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, November 7 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, November 10 TBA Tuesday, November 11 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, November 12 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, November 13 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, November 14 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, November 17 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, November 18 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, November 19 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Thursday, November 20 Foundations of Private Law 9:00 a.m. – 12:30 p.m. Friday, November 21 Legal English Tutorial 9:00 a.m. – 1:00 p.m. -
Date Description Time Monday, November 24 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, November 25 Contract Drafting and Negotiation 9:00 a.m. – 12:30 p.m. Wednesday, November 26 Law School Closed – Thanksgiving Holiday Thursday, November 27 Law School Closed – Thanksgiving Holiday Friday, November 28 Law School Closed – Thanksgiving Holiday -
Date Description Time Monday, December 1 Communication Pragmatics for Lawyers 9:00 a.m. – 12:30 p.m. Tuesday, December 2 Fundamental Lawyering Skills 9:00 a.m. – 12:30 p.m. Wednesday, December 3 Foundations of Private Law Exam 9:00 a.m. – 12:30 p.m. Closing Luncheon and Certificate Ceremony 1:00 – 3:00 p.m.

Location TBA