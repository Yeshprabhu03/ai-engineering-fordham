https://www.fordham.edu/school-of-law/academics/international-programs/jd-study-abroad-programs/summer-jd-study-abroad/south-korea/schedule

# Summer Program in Seoul Schedule

![Fordham South Korea Summer 2023 Program Students in Cart](/media/home/schools/school-of-law/Fordham-South-Korea-Summer-2023-Program-Students-in-Cart.png)


## June 2026

| Date | Description |
|---|---|
June 13 (Sat) - June 14 (Sun) |
Check-in into Program Housing (if applicable) |
June 15 (Mon) - June 21 (Sun) |
Classes (every day) |
June 22 (Mon) |
Reading Day |
June 23 (Tue) |
Exam |
June 25 (Thur)-June 26 (Friday) |
Field Trips |
|
|
Optional Second Course |
June 29 (Mon) or July 6 (Monday) |
Internships begin (if applicable) |