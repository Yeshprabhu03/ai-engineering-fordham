https://www.fordham.edu/school-of-law/alumni/attend/reunion/class-committee

# Class Committee

Rally your class for your Reunion this year

Join a committee of dedicated classmates who want to make this Reunion one for the record books!

**As a Reunion committee member, you will:**

![Fordham Law School Reunion 2016 Women smiling](/media/home/schools/school-of-law/Reunion-4047.jpg)


Serve as a class leader by committing to attend the Reunion and inspiring others to do the same.


![Fordham Law School Reunion Karen Gresia holding sign class '11](/media/home/schools/school-of-law/Make-a-Gift.jpg)


Help reach your class goal! We are counting on 100% participation from all Reunion committee members.

![Fordham Law Reunion](/media/home/schools/school-of-law/Spread-the-Word.jpg)


Volunteer to help make this year memorable by reaching out to classmates to encourage participation and attendance at your Reunion.

![Fordham Law Reunion](/media/home/schools/school-of-law/Meet-the-team-600x399.jpg)


Participate in volunteer conference calls, committee meetings, and take the initiative to reconnect with your classmates.

## Contact Us

If you have any questions about Reunions, please don’t hesitate to contact us at [[email protected]](/cdn-cgi/l/email-protection#bac8dfcfd4d3d5d4fadcd5c8ded2dbd794dfdecf) or 212-636-6529.