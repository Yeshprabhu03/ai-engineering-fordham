https://www.fordham.edu/school-of-law/alumni/attend/reunion/class-of-1976

# Class of 1976

1976 Reunion Committee

John Cashin

Kevin Frawley

David Kapelman

Charles Kenny

Stuart McGregor

![Fordham Law Alumna](https://pxl-fordhamedu.terminalfour.net/fit-in/1500x750/prod01/channel_2/media/home/schools/school-of-law/kaye_laurie.jpg)

I attended the 50 years of FLW seminar yesterday, and was reminded of the female bonds that got me through law school and the realization that we were all in it together and there for each other. (the guys weren’t too shabby either). Great class 1978!

- Laurie Kaye '78**XXXX Registrants**


Class Specific Events

**50th Reunion Dinner **

**May 07, 2026 at 6:00pm**

Interested in giving or have any questions?

Contact US

Classes of 1976, 1986, 1996, or 2006

Contact Lauren Shaw at [[email protected]](/cdn-cgi/l/email-protection#8ae6f9e2ebfdbbb8caece5f8eee2ebe7a4efeeff)


Classes of 1981, 1991, 2001, 2011, or 2021

Contact Juan Nova at [[email protected]](/cdn-cgi/l/email-protection#f09a9e9f8691c3b0969f829498919dde959485)


Classes of 2025

Contact Amelia Wanamaker at [[email protected]](/cdn-cgi/l/email-protection#c1acb6a0afa0aca0aaa4b381a7aeb3a5a9a0acefa4a5b4)