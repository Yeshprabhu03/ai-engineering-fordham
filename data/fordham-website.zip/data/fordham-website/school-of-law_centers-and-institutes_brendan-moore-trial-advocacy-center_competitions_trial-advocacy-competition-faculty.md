https://www.fordham.edu/school-of-law/centers-and-institutes/brendan-moore-trial-advocacy-center/competitions/trial-advocacy-competition-faculty

# Trial Advocacy Competition Faculty

Graham Amodeo

Jeff Briem

Victoria Hill Clarkson

Haseeb Fatmi

Zachary Green

Rishi Gupta

Mike Hardin

Mike Higgins

KellyAnne Holohan

Maddy Mercer

David Mou

Brittany Russell

Adam Shlahet

Jason Tortora

Graham Amodeo

Jeff Briem

Victoria Hill Clarkson

Haseeb Fatmi

Zachary Green

Rishi Gupta

Mike Hardin

Mike Higgins

KellyAnne Holohan

Maddy Mercer

David Mou

Brittany Russell

Adam Shlahet

Jason Tortora