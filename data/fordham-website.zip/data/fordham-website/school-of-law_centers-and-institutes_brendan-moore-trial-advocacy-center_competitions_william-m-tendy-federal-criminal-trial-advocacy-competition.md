https://www.fordham.edu/school-of-law/centers-and-institutes/brendan-moore-trial-advocacy-center/competitions/william-m-tendy-federal-criminal-trial-advocacy-competition

# William M. Tendy Federal Criminal Trial Advocacy Competition

The William M. Tendy Intraschool Competition is the Moores’ annual internal trial tournament. In honor of Mr. Tendy’s work, the problem is a criminal case. Our talented members compete head to head against each other through preliminary, semifinal, and championship rounds. They are judged by Mr. Tendy’s former friends and colleagues, who are distinguished federal practitioners.

William Tendy was a Fordham Law graduate and a thirty year veteran of the United States Attorney’s Office of the Southern District of New York. He ultimately served in the office’s second highest position, Deputy U.S. Attorney, and was described by his boss, U.S. Attorney Rudolph Giuliani, as “a giant in law enforcement.”