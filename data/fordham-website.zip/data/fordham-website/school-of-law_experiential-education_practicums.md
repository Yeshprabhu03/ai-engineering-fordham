https://www.fordham.edu/school-of-law/experiential-education/practicums

# Practicums

Decarceration Practicum

The number of people locked-up in New York State prisons has fallen considerably. Still, over 30,000 men and women remain incarcerated (this does not include thousands of others in pre-trial detention).

Decarceration Practicum

The number of people locked-up in New York State prisons has fallen considerably. Still, over 30,000 men and women remain incarcerated (this does not include thousands of others in pre-trial detention).