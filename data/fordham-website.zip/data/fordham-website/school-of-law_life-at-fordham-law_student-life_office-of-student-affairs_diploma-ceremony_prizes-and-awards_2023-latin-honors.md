https://www.fordham.edu/school-of-law/life-at-fordham-law/student-life/office-of-student-affairs/diploma-ceremony/prizes-and-awards/2023-latin-honors

# 2023 Latin Honors

-
Benjamin Bressler

*, Order of the Coif*Linda Foit,

*Order of the Coif*Caroline Whalen Johnson,

*Order of the Coif*Joseph Hopkins Powers

*, Order of the Coif* -
Peter Curme Angelica

Kielan Barua,

*Order of the Coif*Aydin Benoit-Savci,

*Order of the Coif*Arlene Brooks-Hudak

Katherine Louise Buoymaster,

*Order of the Coif*Elizabeth Ann Cangialosi,

*Order of the Coif*Katharine Grace Cannatella

*, Order of the Coif*Susan Capot

Antonella Ciorciari

Nicolas Christophe Corti

Claudia Curtis

Maria Curutchet

Joshua M. Davis

*, Order of the Coif*Luis Miguel Magsino del Rosario

Edoardo Delzanno

Gabrielle Alena Diaz

*, Order of the Coif*Stephen Eliau

Emma A. Evans

Leigh Margaret Forsyth

*, Order of the Coif*Rosemary Gaidos

Brian L. Giacalone,

*Order of the Coif*Kevin S. Green

*, Order of the Coif*Suzanne Hawkins

Jacqueline Marie Hayes,

*Order of the Coif*Eric Douglas Hechler

Megan Mary Higgins,

*Order of the Coif*Michael Elliot Hirt,

*Order of the Coif*Lauren Leigh Hutwelker,

*Order of the Coif*Caroline C. Kane,

*Order of the Coif*Shane Rode Kuse

*, Order of the Coif*Anastasia Elizabeth Lacina,

*Order of the Coif*Renee Gabrielle Levin,

*Order of the Coif*Sandra Lefkovits

Juliet Liu

*, Order of the Coif*Alysia Lo

*, Order of the Coif*Emily Mandell

Maria Lucila Marchini

Michael McEvoy

Miguel Michel Liriano

Carlo Eugenio Monti

Nicholas R. Pandolfo

*, Order of the Coif*Jose Paredes

Minjung Park

*, Order of the Coif*Andrew Freeman Pauker,

*Order of the Coif*Lillian F. Paulson Stephens,

*Order of the Coif*Nelsy Rivera

Seamus Joseph Ronan

*, Order of the Coif*Katharine Elizabeth Rubery,

*Order of the Coif*Jacob Russell

*, Order of the Coif*Sarah Elizabeth Sanchez Velilla

Kelly Saunders

Alessandro Gennaro Schooley

Timothy W. Schubert

*, Order of the Coif*Isabel Joy Shipman

*, Order of the Coif*Devon Charleen Smith,

*Order of the Coif*Christopher Solis,

*Order of the Coif*Sofi Solomon

Vira Tarnavska,

*Order of the Coif*Michael Thomann

Abigail Tubin

*, Order of the Coif*Deniz Tudor

Kaleb Michael Underwood,

*Order of the Coif*Carly Elyssa Weisen

*, Order of the Coif*Daniel Alexander Weiss

*, Order of the Coif*Avery Michael Wolff

*, Order of the Coif*Noa Zak

-
Antonio J. Aguilera

Josselin M. Aldana-Ng

Dev Ayan Basumallik

Abla S. Belhachmi

Hillary Kristine Bendert

Shira M. Bergman

Katja Bignall-Daly

Alicia Black

Gella Blitz

Georgianna Lane Bonondona

Raymond Braha

Grace Sarah Brennan

Yisroel Mark Brodt

Xinni Cai

Giovanni Candiotto

Melanie Carrozza

Giulia Caselli Maldonado

Danielle Lara Cepelewicz

April Cobb

Benjamin T. Colao

Sara Maria Crupi

Cristiano De Biase

Luke Christian Dechiario

Jason William Denaburg

Christopher Lawrence D’Silva

Grant Maxwell Engel

Edward Hahn Ernst

Kimberly Rose Fishman

James B. Garvey

Nicholas Stephen Gervasi

Jack S. Gilliam

Peter A. Giovine

Sydney Elizabeth Glazer

Micaela Leah Gold

Timothy Robert Gordon

Alexander Patrick Gorka

Elizabeth Foy Gudgel

Atakan Gungordu

Steven A. Halpern

Michael Thomas Hamilton

Annmarie B. Heneghan

Yuki Hirose

Katherine B. Hyman

Shana A. Iden

Julian Iragorri

Jenela Jack

Gregory Francis James

Liviya Camille James

Emily Elizabeth Jensen

Madeline Claire Johl

Gesa Junge

Cameron Anastasia Kasanzew

Millicent Jade Kastenbaum

Seo Kyung Kim

Amy Gina Kim

Amira Njeri Kingori

Isaac Andrew Krier

Jessica L. Lagnado

Cristina Sara Anna Langford

Isabelle Leipziger

Leo Lemaire

Benjamin Lew

Sean Stephen Malone

Louis Mandeville-Peiriere

Jacob Christopher Marcus

Jonathan Margareten

Jacqueline Marmora

Akiva Mase

Alana Grace McAndrews

Daniel James McAuliffe

Maya Syngal McGrath

Colleen McGuire

Siobhan McKenna

Maura Ann McKeon

Caitlin Beth McNeil

Kenza Mena

Natalia Merkoulova

Gregory Miele

Spencer Bulkley Mooney

Patrick Barrett Murphy

Satoko Nakamura

Lindsey Neuberger

Jonathan Anthony Ohlmann

Marc Ryan Osian

Miles Courtland Patton

Morgan Paugh

Alexis Pawlowski

Edoardo Picchi

Francesco Planchenstainer

Michael Mario Rasmussen

Kate Lauren Reinertson

Guillaume Remond

Matthew Roomberg

Thomas C. Rukaj

Tess Parker Savage

Devin T. Savaskan

Stephanie Jo Scanzillo

Lauren Elizabeth Schadt

Michael Holden Scheinthal

Sarah Schwimmbeck

Allison Claire Scott

Sarah Sooyeon Seo

Graham Noah Streich

Philip Soto

Grace L. Sullivan

Katharine L. Tubby

Carla Velasco Edgar

Maria Villaggi

Pearse Dillon Bard Walsh

Mengjia Wang

Yannick Weill

Celeste Belinsky Williams

Parker Rose Wingate

Leila A. Witcher

Nadia Withers

Yuchen Xie

Stephen Young

Zachary R. Zajdel

Hanna J. Zaretsky