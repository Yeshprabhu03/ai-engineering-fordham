https://www.fordham.edu/school-of-law/life-at-fordham-law/student-life/student-competitions/fordham-dispute-resolution-society/masthead

# Dispute Resolution Society Masthead

## 2024-2025

| Executive Board | ||
|---|---|---|
|
CARALINE M. HIGGINS |
CHRISTIAN SUGLIA |
HIRA MUSTAFA |

| Editorial Board | ||
|---|---|---|
|
SARAH HARTMAN ADRIANA MUNSIE JACK BIDDLE SOPHIA BRUSCO BEN GREENSPON JEEYOON LIM |
CRISTIAN A. VEGA MICHAEL FRIED BRIANNA COURTNEY AMANDA COOPER AUDREY NELSON CATE A. GILLHAM |
ALINA EKBAL TALIN A. GHAZARIAN CATRIONA LECKIE ALEXANDRA WILDMAN ABIGAIL GHANTOUS BERTHA MAHAMA |

| 3L Competitors | ||||||
|---|---|---|---|---|---|---|
|
KAYLA BAKHSHI |
ROB DEBENEDETTI |
JILLIAN KEYES JAVIER MELENDEZ KAITLYN SIVERTSEN JOHN M. SPAULDING |

| Associate Editors | ||||||
|---|---|---|---|---|---|---|
|
KAYLA BAKHSHI |
KEVIN JONES |
GABBY SANCHEZ |

| Competitors | ||||||
|---|---|---|---|---|---|---|
|
DEVIN B. ABLOW |
ASHLEY FUNG |
BERTHA MAHAMA |

## Competition Team Roster

ABA Negotiation |
ABA Arbitration |
|---|---|
|
JORDAN BLUM |
NATALI AL JUNDY |

ICC Mediation |
INADR Mediation |
|---|---|
|
ELI FISHER |
NINA AKKER |

ABA Mediation |
CPR Mediation |
|---|---|
|
ALLEYAH ALLY |
GAVALLIA BEAUVAIS |

| VIS East/West Arbitration | 3L Competition |
|---|---|
|
DEVIN B. ABLOW |
KAYLA BAKHSHI |