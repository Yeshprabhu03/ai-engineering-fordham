https://www.fordham.edu/school-of-professional-and-continuing-studies/academics/real-estate-institute/academics/professional-certificates-and-continuing-education

# Real Estate Institute Professional Certificates and Continuing Education

Fordham REI continuing education courses are **six-week ****asynchronous ****online** classes that allow students to view instructional materials each week at a time that works for them and implement newly gained knowledge and skills immediately.

**At a Glance**

- 100% online
- Flexible, convenient study schedule
- Learn from industry experts
- Build your professional skills immediately

**Refund Policy **

**For six-module, noncredit online courses:** Students are eligible for a 100% tuition refund if they withdraw from the course within 3 calendar days of the date of registration. No refund thereafter.