https://www.fordham.edu/school-of-professional-and-continuing-studies/academics/real-estate-institute/academics/professional-certificates-and-continuing-education/refund-policy

# REI Professional Certificate Refund Policy

**For six-module, noncredit online courses:** Students are eligible for a 100% tuition refund if they withdraw from the course within 3 calendar days of the date of registration. No refund thereafter.

**For one-week noncredit intensive courses:** Students are eligible for a 100% tuition refund if they withdraw from the course before the official start date. If the intensive has already started, the refund schedule is as follows: 50% refund if the student withdraws before the third scheduled session. No refund thereafter.