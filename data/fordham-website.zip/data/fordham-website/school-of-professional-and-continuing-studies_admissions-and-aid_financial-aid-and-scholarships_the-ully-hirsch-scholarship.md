https://www.fordham.edu/school-of-professional-and-continuing-studies/admissions-and-aid/financial-aid-and-scholarships/the-ully-hirsch-scholarship

# The Ully Hirsch Scholarship

**The Ully Hirsch Scholarship**, awarded annually to a student who has demonstrated academic excellence by achieving a 3.0 cumulative GPA after earning at least 24 credits.

**The Ully Hirsch Scholarship**, awarded annually to a student who has demonstrated academic excellence by achieving a 3.0 cumulative GPA after earning at least 24 credits.