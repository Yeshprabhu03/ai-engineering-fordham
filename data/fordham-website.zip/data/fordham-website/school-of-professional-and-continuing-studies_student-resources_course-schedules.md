https://www.fordham.edu/school-of-professional-and-continuing-studies/student-resources/course-schedules

# PCS Course Schedules

### Spring 2026 registration opens on October 27, 2025. Seats fill fast!

**New student registration opens on November 17, 2025.**

![Professor Lectures students in conference toom](/media/review/content-assets/migrated/images/F_0392BX_2.jpg)

We encourage you to contact your advisor before registering. If you have already been advised and would like to register yourself, please view the [complete registration instructions](/about/leadership-and-administration/administrative-offices/enrollment-group/academic-records/registration-information/).

If you have any questions, please contact us:

**Lincoln Center Students:** 212-636-6372, [[email protected]](/cdn-cgi/l/email-protection#f9899a959d9c98978ab99f968b9d919894d79c9d8c)**Rose Hill Students:** 718-817-4600**Westchester Students:** 914-367-3303**Post Bac Students: **[[email protected]](/cdn-cgi/l/email-protection#ec9c839f988e8d8fac8a839e88848d81c2898899)

General Email:[[email protected]](/cdn-cgi/l/email-protection#e79784948e898188a7818895838f868ac9828392)