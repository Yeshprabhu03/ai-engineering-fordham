https://www.fordham.edu/student-life/deans-of-students-and-student-life/student-handbook/university-regulations/a---z-listing/fund-raising

# Student Handbook: Fund Raising

Only the President is authorized to accept donations and gifts to the University. For this reason, the solicitation and acceptance of gifts restricted to specific projects and programs must be cleared with the Vice President for Development and University Relations since it is not always practical and feasible for the University to accept such gifts. Student Organizations must coordinate fundraising with the Office for Student Involvement and/or their relevant academic unit.