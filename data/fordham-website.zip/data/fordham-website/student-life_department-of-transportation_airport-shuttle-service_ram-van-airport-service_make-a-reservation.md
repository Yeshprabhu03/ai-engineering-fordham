https://www.fordham.edu/student-life/department-of-transportation/airport-shuttle-service/ram-van-airport-service/make-a-reservation

# Ram Van Outbound Airport Service: Make a Reservation

Make a reservation for airport services through the [Airport Store](https://secure.touchnet.com/C20175_ustores/web/store_main.jsp?STOREID=4&SINGLESTORE=true). Please note that your Fordham account will be needed to log in and purchase tickets using our system.

Make a reservation for airport services through the [Airport Store](https://secure.touchnet.com/C20175_ustores/web/store_main.jsp?STOREID=4&SINGLESTORE=true). Please note that your Fordham account will be needed to log in and purchase tickets using our system.