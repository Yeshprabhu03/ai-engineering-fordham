https://www.fordham.edu/student-life/department-of-transportation/local-transportation-and-directions/maps-and-directions

# Maps and Directions

[Lincoln Center and Directions](/about/maps-and-directions/lincoln-center-campus/)

113 W 60th Street

New York, NY 10023

212-636-6000

[Rose Hill Campus and Directions](/about/maps-and-directions/rose-hill-campus/)

441 East Fordham Road

Bronx, NY 10458

718-817-1000

[Westchester Campus](/about/maps-and-directions/westchester-campus/)

400 Westchester Avenue

West Harrison, NY 10604

[Lincoln Center and Directions](/about/maps-and-directions/lincoln-center-campus/)

113 W 60th Street

New York, NY 10023

212-636-6000

[Rose Hill Campus and Directions](/about/maps-and-directions/rose-hill-campus/)

441 East Fordham Road

Bronx, NY 10458

718-817-1000

[Westchester Campus](/about/maps-and-directions/westchester-campus/)

400 Westchester Avenue

West Harrison, NY 10604