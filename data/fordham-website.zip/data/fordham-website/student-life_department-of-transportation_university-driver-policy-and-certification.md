https://www.fordham.edu/student-life/department-of-transportation/university-driver-policy-and-certification

# Ram Van Driver Policy and Certification

In some instances, students that are members of athletics teams or Campus Ministry may become certified to drive University vehicles.

Driving a vehicle is a serious responsibility, and only those able to fully and completely follow the steps outlined in this section will be able to do so.

If you consider getting certified, please thoroughly review all information in this section. The entire certification process must be completed at least two weeks before your group's scheduled trip date. Please begin early!