https://www.fordham.edu/student-life/multicultural-affairs/about-oma/meet-the-team

# Office of Multicultural Affairs Team

**Full-Time Staff**

[Juan Carlos Matos](/student-life/multicultural-affairs/about-oma/meet-the-team/more-about-our-full-time-staff/)*Assistant Vice President for Student Affairs for Diversity and Inclusion*[[email protected]](/cdn-cgi/l/email-protection)

McShane Center, Suite 283

Marie Castro*Assistant Director at Lincoln Center, Office of Multicultural Affairs*[[email protected]](/cdn-cgi/l/email-protection)

140 West 62nd, G43

Rashain Adams*Assistant Director at Rose Hill, Office of Multicultural Affairs*[[email protected]](/cdn-cgi/l/email-protection)

McShane Center, Suite 283

To reach the team on any matters related to Multicultural Affairs and DEIB, please email [[email protected]](/cdn-cgi/l/email-protection).

**Graduate Interns**

Rose Hill

Location: McShane Campus Center, Suite 283

Brianna Perez (She/Her)

Annabelle Baulch (She/Her)

Lincoln Center

Location: 140 West 62nd Street, Room G41

Katrina Manansala (She/They)