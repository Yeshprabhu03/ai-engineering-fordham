https://www.fordham.edu/student-life/safety-health-and-wellness/health-services/health-center/medical-services/mens-health-care

# Men's Health Care

Men’s Health is about the care and treatment of health concerns unique to being male. University Health Services provides evaluation and treatment for sexual health issues such as HIV testing along with check-up, diagnosis and treatment of STI’s. For more complicated, complex problems, off-campus referrals are available.

Contact the
[Health Center](/student-life/safety-health-and-wellness/health-services/health-center/) with any questions.