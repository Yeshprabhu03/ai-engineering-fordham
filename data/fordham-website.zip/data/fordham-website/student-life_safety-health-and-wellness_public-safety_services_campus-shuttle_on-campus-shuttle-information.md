https://www.fordham.edu/student-life/safety-health-and-wellness/public-safety/services/campus-shuttle/on-campus-shuttle-information

# On-Campus Shuttle Information

## On Campus Shuttle Information

The Department of Public Safety operates an on-campus shuttle for members of the Fordham community. The on-campus shuttle is available Monday through Friday from 7:30 am until 7:00 pm. The on campus shuttle does not operate during University holidays or during weather related campus closures.

** The following is a list of designated shuttle stops:**

- Front of McGinley Center
- Front of Fordham Prep
- Rear of Loschert Hall
- Front of Lalande Hall
- Admin/Collins/Huges
- 3rd Avenue Gate
- Walsh Library
- Duane Library
- Thebaud/Dealy
- Security/Finlay Hall
- Freeman
- JMH
- Tierney Hall
- Regional Garage