https://www.fordham.edu/student-life/student-involvement/office-for-student-involvement-at-rose-hill/the-mcshane-campus-center/contact-us

# Contacting the McShane Center

Do you have a question? If so, please feel free to contact us.

Event Technical Assistance: 929-251-3170

General Information Number: 718-817-4339

Fax: 718-817-4375

Office Location: McShane Center, Room 270[[email protected]](/cdn-cgi/l/email-protection#83e0e2eef3f6f0e0e6edf7e6f1ecf3e6f1e2f7eaecedf0c3e5ecf1e7ebe2eeade6e7f6)

Mailing Address:

Fordham University Campus Center Operations

McShane Center Room 270

441 East Fordham Road

Bronx, NY 10458